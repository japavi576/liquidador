import React, { useState, useEffect } from 'react';
import { AppStorageService } from '../services/storageService';
import { Liquidacion, Persona, DetalleConcepto, Venta, DetallesParametrizacion, RangoComision } from '../types';
import { History, Trash2, Search, ChevronDown, ChevronRight, Loader2, X, Check, Wrench, Play, Save, Hash, CalendarDays, DollarSign, Target, Percent, ArrowRight, Minus, Terminal } from 'lucide-react';

const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(val);
};

const formatPercent = (val: number) => {
    return new Intl.NumberFormat('es-CO', {
        minimumFractionDigits: 1,
        maximumFractionDigits: 2
    }).format(val) + '%';
};

export default function LiquidationHistory({ storage }: { storage: AppStorageService }) {
  const [liquidaciones, setLiquidaciones] = useState<Liquidacion[]>([]);
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [filter, setFilter] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  
  // Adjustment states
  const [showAdjustModal, setShowAdjustModal] = useState(false);
  const [adjustingLiq, setAdjustingLiq] = useState<Liquidacion | null>(null);
  const [tempPersona, setTempPersona] = useState<Persona | null>(null);
  const [adjustPeriod, setAdjustPeriod] = useState({ 
    anio: 2024, 
    mes: 1, 
    dia: 'all' as number | 'all',
    tipo: 3 as number 
  });
  const [adjustResult, setAdjustResult] = useState<Liquidacion | null>(null);
  const [calculatingAdjust, setCalculatingAdjust] = useState(false);
  const [theoreticalTotal, setTheoreticalTotal] = useState(0);
  const [calculationLog, setCalculationLog] = useState<string[]>([]);
  const [showLogs, setShowLogs] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
        const data = await storage.listLiquidaciones();
        setLiquidaciones(data);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, []);

  const normalize = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();

  const executeDelete = async (liq: Liquidacion) => {
      setDeletingId(liq.id);
      try {
          await storage.deleteLiquidacion(liq);
          setLiquidaciones(prev => prev.filter(l => l.id !== liq.id));
      } catch (err) { alert("Error al eliminar."); } finally { setDeletingId(null); setConfirmDeleteId(null); }
  };

  const handleOpenAdjust = async (liq: Liquidacion) => {
      setAdjustingLiq(liq);
      setAdjustPeriod({ 
        anio: liq.periodo.anio, 
        mes: liq.periodo.mes, 
        dia: liq.periodo.dia || 'all',
        tipo: liq.periodo_id || 3 
      });
      setAdjustResult(null);
      setTheoreticalTotal(0);
      setCalculationLog([]);
      setShowLogs(false);
      
      const personas = await storage.getAllPersonas();
      const p = personas.find(pers => pers.nit === liq.persona_nit);
      if (p) {
          setTempPersona(JSON.parse(JSON.stringify(p)));
      } else {
          alert("No se encontró el líder original.");
      }
      setShowAdjustModal(true);
  };

  const calculateAdjustment = async () => {
      if (!tempPersona || !adjustingLiq) return;
      setCalculatingAdjust(true);
      setCalculationLog([]);
      const logs: string[] = [];
      const log = (msg: string) => logs.push(msg);

      try {
          log(`=== INICIO DE CÁLCULO DE AJUSTE ===`);
          log(`Líder: ${tempPersona.nombre} (NIT: ${tempPersona.nit})`);
          log(`Periodo Objetivo: Año ${adjustPeriod.anio}, Mes ${adjustPeriod.mes}, Filtro Día ${adjustPeriod.dia}`);

          const ventasRaw = await storage.getVentasForPeriod(adjustPeriod.anio, adjustPeriod.mes);
          
          if (ventasRaw.length === 0) { 
              alert("No hay ventas para este periodo."); 
              log("ERROR: No se encontraron ventas en el storage para este periodo.");
              setCalculationLog(logs);
              setCalculatingAdjust(false); 
              return; 
          }
          log(`Ventas totales encontradas en periodo: ${ventasRaw.length} registros`);
          
          const uniqueDays = Array.from(new Set(ventasRaw.map(v => v.dia))).sort((a,b) => Number(a)-Number(b));
          log(`Días con ventas disponibles en sistema: ${uniqueDays.join(', ')}`);

          // Aggregate unique sales
          const aggregatedMap = new Map<string, Venta>();
          ventasRaw.forEach(v => {
              const key = `${v.bodega}-${v.anio}-${v.mes}-${v.dia}-${normalize(v.tipo_venta)}`;
              if (aggregatedMap.has(key)) { aggregatedMap.get(key)!.valor += v.valor; } 
              else { aggregatedMap.set(key, { ...v }); }
          });
          const collapsed = Array.from(aggregatedMap.values());
          log(`Registros únicos consolidados: ${collapsed.length}`);

          // Filter by Cutoff Day OR Specific Day
          let filteredVentas = collapsed;
          if (adjustPeriod.dia !== 'all') {
              // CHANGE: Strict equality to filter ONLY the selected day, not accumulated
              filteredVentas = collapsed.filter(v => Number(v.dia) === Number(adjustPeriod.dia));
              log(`Filtrado ESPECÍFICO por día ${adjustPeriod.dia}: ${filteredVentas.length} registros seleccionados.`);
          } else {
              log(`Mes completo seleccionado (Todas las ventas del mes).`);
          }
          
          const pBodegas = tempPersona.bodegas.map(b => normalize(b));
          log(`Bodegas asignadas al líder: ${pBodegas.join(', ')}`);
          
          const personSales = filteredVentas.filter(v => pBodegas.includes(normalize(String(v.bodega))));
          log(`Ventas coincidentes con bodegas del líder: ${personSales.length}`);
          
          if (personSales.length === 0) { 
              alert("Sin ventas para este líder en los filtros seleccionados."); 
              log("ADVERTENCIA: 0 Ventas encontradas para las bodegas del líder en el día seleccionado.");
              setCalculationLog(logs);
              setCalculatingAdjust(false); 
              return; 
          }
          
          let newTheoreticalComisionTotal = 0;
          let newTheoreticalVentasTotal = 0;
          const theoreticalConceptos: DetalleConcepto[] = [];
          const bodegaMap: Record<string, number> = {};

          personSales.forEach(v => {
            bodegaMap[v.bodega] = (bodegaMap[v.bodega] || 0) + v.valor;
            newTheoreticalVentasTotal += v.valor;
          });
          log(`Total Ventas Base del Líder (Filtrado): ${formatCurrency(newTheoreticalVentasTotal)}`);

          log(`--- PROCESANDO REGLAS DE PARAMETRIZACIÓN ---`);
          for (const param of (tempPersona.parametrizacion || [])) {
              log(`\n>> Evaluando Concepto: ${param.tipo}`);
              const paramNorm = normalize(param.tipo);
              const salesForType = personSales.filter(v => normalize(v.tipo_venta).includes(paramNorm));
              const vTotal = salesForType.reduce((s, v) => s + v.valor, 0);
              log(`   Ventas detectadas para concepto: ${formatCurrency(vTotal)}`);
              
              let detalles: DetallesParametrizacion | null = null;
              let segUsado = '';

              const hasMeta = (d: DetallesParametrizacion) => {
                  if (d.modo === 'META_UNICA') return (d.metaUnica.meta || 0) > 0;
                  return d.rangos.some(r => (r.meta || 0) > 0);
              };

              if (param.segmentos['TODO'] && hasMeta(param.segmentos['TODO'])) { detalles = param.segmentos['TODO']; segUsado = 'TODO'; } 
              else if (param.segmentos['GENERAL'] && hasMeta(param.segmentos['GENERAL'])) { detalles = param.segmentos['GENERAL']; segUsado = 'GENERAL'; }
              else {
                  const keys = Object.keys(param.segmentos);
                  const validKey = keys.find(k => hasMeta(param.segmentos[k]));
                  if (validKey) { detalles = param.segmentos[validKey]; segUsado = validKey; }
                  else if (keys.length > 0) { detalles = param.segmentos[keys[0]]; segUsado = keys[0]; }
              }

              if (!detalles) {
                  log(`   SKIPPED: No se encontró configuración válida (Meta > 0) para ningún segmento.`);
                  continue;
              }
              log(`   Segmento aplicado: ${segUsado}`);
              log(`   Modo de cálculo: ${detalles.modo}`);

              let comision = 0;
              let meta = 0;
              let cump = 0;
              
              // CRITICAL FIX: Sort ranges descending by min value to ensure highest tier is matched first
              const sortedRangos = [...detalles.rangos].sort((a, b) => {
                  const minA = a.min ?? -Infinity;
                  const minB = b.min ?? -Infinity;
                  return minB - minA; // Descending order
              });
              
              if (detalles.modo === 'META_UNICA') {
                  meta = detalles.metaUnica.meta || 0;
                  cump = meta > 0 ? (vTotal / meta) * 100 : 0;
                  log(`   Meta Única: ${formatCurrency(meta)}. Cumplimiento: ${cump.toFixed(2)}%`);
                  
                  if (vTotal >= meta) {
                      const pct = detalles.metaUnica.porcentaje || 0;
                      const val = detalles.metaUnica.valor || 0;
                      comision = (vTotal * (pct / 100)) + val;
                      log(`   CUMPLE META. Aplica ${pct}% + ${formatCurrency(val)}`);
                  } else {
                      log(`   NO CUMPLE META.`);
                  }
              } else {
                  // Find the first range that has a meta to use as the reference meta for calculation
                  const rMeta = detalles.rangos.find(r => r.meta && r.meta > 0);
                  meta = rMeta ? rMeta.meta : 0;
                  cump = meta > 0 ? (vTotal / meta) * 100 : 0;
                  log(`   Meta Referencia (del primer rango válido): ${formatCurrency(meta)}`);
                  log(`   Cumplimiento Calculado: ${cump.toFixed(4)}%`);
                  
                  log(`   Evaluando rangos (Ordenados por Min Descendente):`);
                  // Use the SORTED ranges to find the match
                  const match = sortedRangos.find(r => {
                      const min = r.min ?? -Infinity;
                      const max = r.max ?? Infinity;
                      let matches = false;
                      if (r.operador === 'ENTRE') matches = cump >= min && cump <= max;
                      else if (r.operador === 'MAYOR_IGUAL') matches = cump >= min;
                      else if (r.operador === 'MENOR_IGUAL') matches = cump <= max;
                      
                      log(`     - [${r.operador}] Min:${min === -Infinity ? '-Inf' : min}, Max:${max === Infinity ? 'Inf' : max} -> %Com:${r.porcentaje} -> ${matches ? 'MATCH' : 'NO'}`);
                      return matches;
                  });
                  
                  if (match) {
                      const pct = match.porcentaje || 0;
                      const val = match.valor || 0;
                      const comisionPct = (vTotal * (pct / 100));
                      comision = comisionPct + val;
                      log(`   MATCH FINAL: ${pct}% + ${formatCurrency(val)}`);
                      log(`   Cálculo: (${formatCurrency(vTotal)} * ${pct}%) = ${formatCurrency(comisionPct)} + Fijo ${formatCurrency(val)} = ${formatCurrency(comision)}`);
                  } else {
                      log(`   NO MATCH: Ningún rango coincidió.`);
                  }
              }

              newTheoreticalComisionTotal += comision;
              theoreticalConceptos.push({
                  concepto: param.tipo,
                  segmento_aplicado: segUsado,
                  venta_total: vTotal,
                  meta_objetivo: meta,
                  porcentaje_cumplimiento: cump,
                  comision_porcentaje_aplicado: 0,
                  comision_valor_fijo_aplicado: 0,
                  total_concepto: comision,
                  mensaje: 'Resultado Teórico'
              });
          }

          setTheoreticalTotal(newTheoreticalComisionTotal);
          log(`\n=== RESULTADO FINAL ===`);
          log(`Total Comisión Teórica: ${formatCurrency(newTheoreticalComisionTotal)}`);

          const deltaComision = newTheoreticalComisionTotal - adjustingLiq.comision_total;
          const deltaVentas = newTheoreticalVentasTotal - adjustingLiq.total_ventas;

          const adjustmentConceptos: DetalleConcepto[] = theoreticalConceptos.map(newDet => {
              const oldDet = adjustingLiq.detalles_conceptos.find(d => d.concepto === newDet.concepto);
              return {
                  ...newDet,
                  venta_total: newDet.venta_total - (oldDet?.venta_total || 0),
                  total_concepto: newDet.total_concepto - (oldDet?.total_concepto || 0),
                  mensaje: `Ajuste vs Original (${adjustingLiq.id.substring(0,8)})`
              };
          });

          setAdjustResult({
              id: crypto.randomUUID(),
              periodo_id: adjustPeriod.tipo,
              fecha_calculo: new Date().toISOString(),
              periodo: { anio: adjustPeriod.anio, mes: adjustPeriod.mes, dia: adjustPeriod.dia },
              persona_nit: tempPersona.nit,
              persona_nombre: tempPersona.nombre,
              total_ventas: deltaVentas,
              comision_total: deltaComision,
              detalles_conceptos: adjustmentConceptos,
              detalle_bodegas: Object.entries(bodegaMap).map(([b, v]) => ({ bodega: b, valor: v })),
              es_ajuste: true,
              original_id: adjustingLiq.id
          });
          
          setCalculationLog(logs);

      } catch (e: any) { 
          alert("Error: " + e.message); 
          log(`ERROR CRÍTICO: ${e.message}`);
          setCalculationLog(logs);
      } finally { setCalculatingAdjust(false); }
  };

  const saveAdjustment = async () => {
      if (!adjustResult) return;
      setLoading(true);
      try {
          await storage.saveLiquidacion(adjustResult);
          alert("¡Ajuste guardado exitosamente!");
          setShowAdjustModal(false);
          loadData();
      } catch (e: any) { alert("Error al guardar."); } finally { setLoading(false); }
  };

  const filtered = liquidaciones.filter(l => 
    l.persona_nombre.toLowerCase().includes(filter.toLowerCase()) || 
    l.persona_nit.includes(filter) ||
    `${l.periodo.anio}-${l.periodo.mes}`.includes(filter)
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800">Historial de Liquidaciones</h2>
        <button onClick={loadData} disabled={loading} className="text-sm text-blue-600 font-medium hover:underline flex items-center gap-1">
            <History className="w-4 h-4" /> Refrescar
        </button>
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex items-center gap-3">
          <Search className="w-5 h-5 text-slate-400" />
          <input type="text" placeholder="Filtrar por nombre, NIT o periodo..." className="flex-1 outline-none text-sm" value={filter} onChange={e => setFilter(e.target.value)} />
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          {loading ? (
              <div className="p-12 text-center text-slate-400 animate-pulse">Cargando registros...</div>
          ) : filtered.length === 0 ? (
              <div className="p-12 text-center text-slate-400">No se encontraron registros en el historial.</div>
          ) : (
              <div className="overflow-x-auto">
                  <table className="w-full text-[11px] text-left">
                      <thead className="bg-slate-50 text-slate-500 uppercase font-black border-b border-slate-200 tracking-wider">
                          <tr>
                              <th className="p-4 w-8"></th>
                              <th className="p-4">ID / Tipo</th>
                              <th className="p-4">Año</th>
                              <th className="p-4">Mes</th>
                              <th className="p-4 text-center">ID Periodo</th>
                              <th className="p-4 text-center">Día Corte</th>
                              <th className="p-4">NIT / Cédula</th>
                              <th className="p-4">Líder</th>
                              <th className="p-4 text-right">Comisión</th>
                              <th className="p-4 text-center">Acciones</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {filtered.map(liq => (
                              <React.Fragment key={liq.id}>
                                  <tr className={`hover:bg-slate-50 transition-colors ${expandedId === liq.id ? 'bg-blue-50/30' : ''}`}>
                                      <td className="p-4 text-center">
                                          <button onClick={() => setExpandedId(expandedId === liq.id ? null : liq.id)} className="p-1 hover:bg-slate-200 rounded">
                                              {expandedId === liq.id ? <ChevronDown className="w-4 h-4 text-blue-500" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                                          </button>
                                      </td>
                                      <td className="p-4">
                                          <div className="flex items-center gap-1 mb-1 font-mono text-[9px] text-slate-400">
                                              <Hash className="w-3 h-3" />
                                              {liq.id.substring(0, 8)}
                                          </div>
                                          {liq.es_ajuste ? (
                                              <span className="bg-orange-600 text-white px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest shadow-sm">AJUSTE</span>
                                          ) : (
                                              <span className="bg-slate-800 text-white px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest shadow-sm">ORIGINAL</span>
                                          )}
                                      </td>
                                      <td className="p-4 font-bold text-slate-700">{liq.periodo.anio}</td>
                                      <td className="p-4 font-bold text-slate-700 capitalize">{new Date(0, liq.periodo.mes-1).toLocaleString('es', { month: 'long' })}</td>
                                      <td className="p-4 text-center">
                                          <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-[10px] font-black shadow-sm">{liq.periodo_id}</span>
                                      </td>
                                      <td className="p-4 text-center font-bold text-slate-600">
                                          {liq.periodo.dia === 'all' ? 'Mes Comp.' : `Día ${liq.periodo.dia}`}
                                      </td>
                                      <td className="p-4 font-mono text-slate-500">{liq.persona_nit}</td>
                                      <td className="p-4 font-bold text-slate-800 uppercase">{liq.persona_nombre}</td>
                                      <td className="p-4 text-right">
                                          <div className={`font-black text-lg tracking-tighter ${liq.comision_total >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                              {formatCurrency(liq.comision_total)}
                                          </div>
                                      </td>
                                      <td className="p-4 text-center">
                                          <div className="flex justify-center items-center gap-2">
                                              {!liq.es_ajuste && (
                                                <button onClick={() => handleOpenAdjust(liq)} className="p-2 text-slate-400 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-all" title="Ajustar Liquidación">
                                                    <Wrench className="w-4 h-4" />
                                                </button>
                                              )}
                                              {confirmDeleteId === liq.id ? (
                                                  <div className="flex items-center gap-1 animate-in slide-in-from-right-2">
                                                      <button onClick={() => executeDelete(liq)} className="bg-red-600 text-white p-1.5 rounded-lg shadow-sm"><Check className="w-3.5 h-3.5" /></button>
                                                      <button onClick={() => setConfirmDeleteId(null)} className="bg-slate-200 text-slate-600 p-1.5 rounded-lg shadow-sm"><X className="w-3.5 h-3.5" /></button>
                                                  </div>
                                              ) : (
                                                  <button onClick={() => setConfirmDeleteId(liq.id)} disabled={deletingId !== null} className="p-2 text-slate-300 hover:text-red-600 rounded-lg transition-all">
                                                      {deletingId === liq.id ? <Loader2 className="w-4 h-4 animate-spin text-red-500" /> : <Trash2 className="w-4 h-4" />}
                                                  </button>
                                              )}
                                          </div>
                                      </td>
                                  </tr>
                                  {expandedId === liq.id && (
                                      <tr><td colSpan={10} className="bg-slate-50 p-6 border-b border-slate-200">
                                          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden p-6 animate-in slide-in-from-top-2">
                                              <div className="text-[9px] font-black text-slate-400 mb-4 uppercase tracking-widest border-b pb-2">Desglose de Conceptos</div>
                                              <table className="w-full text-[10px]">
                                                  <thead className="text-slate-400 font-bold uppercase tracking-wider">
                                                      <tr>
                                                          <th className="p-2 text-left">Concepto</th>
                                                          <th className="p-2 text-right">Venta (Periodo/Dif)</th>
                                                          <th className="p-2 text-right">Meta Ref.</th>
                                                          <th className="p-2 text-right">Cumplimiento</th>
                                                          <th className="p-2 text-right">Comisión</th>
                                                      </tr>
                                                  </thead>
                                                  <tbody className="divide-y divide-slate-50">
                                                      {liq.detalles_conceptos.map((det, idx) => (
                                                          <tr key={idx}>
                                                              <td className="p-2 font-bold text-slate-700">{det.concepto}</td>
                                                              <td className="p-2 text-right text-slate-500">{formatCurrency(det.venta_total)}</td>
                                                              <td className="p-2 text-right text-slate-400">{formatCurrency(det.meta_objetivo)}</td>
                                                              <td className="p-2 text-right"><span className={`px-2 py-0.5 rounded-full font-black ${det.porcentaje_cumplimiento >= 100 ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'}`}>{det.porcentaje_cumplimiento.toFixed(1)}%</span></td>
                                                              <td className={`p-2 text-right font-black text-sm ${det.total_concepto >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                                                                  {formatCurrency(det.total_concepto)}
                                                              </td>
                                                          </tr>
                                                      ))}
                                                  </tbody>
                                              </table>
                                          </div>
                                      </td></tr>
                                  )}
                              </React.Fragment>
                          ))}
                      </tbody>
                  </table>
              </div>
          )}
      </div>

      {showAdjustModal && tempPersona && adjustingLiq && (
          <div className="fixed inset-0 z-[60] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 md:p-8 animate-in fade-in">
              <div className="bg-white w-full h-full max-w-5xl rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-slate-300">
                  <div className="p-6 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
                      <div className="flex items-center gap-4">
                          <div className="p-3 bg-orange-100 rounded-xl text-orange-600 shadow-sm"><Wrench className="w-6 h-6" /></div>
                          <div>
                              <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Ajustar Liquidación: {tempPersona.nombre}</h3>
                              <p className="text-xs text-slate-500">Recalcula la comisión según nuevas fechas y resta el valor liquidado anteriormente.</p>
                          </div>
                      </div>
                      <button onClick={() => setShowAdjustModal(false)} className="p-2 hover:bg-slate-200 rounded-full transition-colors"><X className="w-6 h-6 text-slate-400" /></button>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-6 space-y-6">
                      
                      {/* Original Summary */}
                      <div className="bg-slate-100 rounded-xl p-4 flex justify-between items-center border border-slate-200">
                          <div>
                              <p className="text-[10px] font-bold text-slate-400 uppercase mb-1 tracking-widest">Valor Original Liquidado</p>
                              <p className="text-xl font-black text-slate-600">{formatCurrency(adjustingLiq.comision_total)}</p>
                          </div>
                          <div className="text-right">
                              <p className="text-[10px] font-bold text-slate-400 uppercase mb-1 tracking-widest">ID Original</p>
                              <p className="text-[10px] font-mono bg-white px-2 py-1 rounded border border-slate-200">{adjustingLiq.id}</p>
                          </div>
                      </div>

                      {/* Recalculate Controls */}
                      <section className="bg-white rounded-2xl border border-slate-200 p-6 grid grid-cols-1 md:grid-cols-5 gap-4 items-end shadow-sm">
                            <div>
                                <label className="text-[10px] font-bold text-slate-400 block mb-1 uppercase tracking-widest">Año</label>
                                <input type="number" value={adjustPeriod.anio} onChange={e => setAdjustPeriod({...adjustPeriod, anio: parseInt(e.target.value)})} className="w-full border border-slate-200 rounded-xl p-3 font-bold text-sm outline-none focus:ring-2 focus:ring-blue-500" />
                            </div>
                            <div>
                                <label className="text-[10px] font-bold text-slate-400 block mb-1 uppercase tracking-widest">Mes</label>
                                <select value={adjustPeriod.mes} onChange={e => setAdjustPeriod({...adjustPeriod, mes: parseInt(e.target.value)})} className="w-full border border-slate-200 rounded-xl p-3 font-bold text-sm outline-none focus:ring-2 focus:ring-blue-500">
                                    {[...Array(12)].map((_, i) => <option key={i+1} value={i+1}>{new Date(0, i).toLocaleString('es', { month: 'long' })}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="text-[10px] font-bold text-slate-400 block mb-1 uppercase tracking-widest">Día de Corte</label>
                                <select value={adjustPeriod.dia} onChange={e => setAdjustPeriod({...adjustPeriod, dia: e.target.value === 'all' ? 'all' : parseInt(e.target.value)})} className="w-full border border-slate-200 rounded-xl p-3 font-bold text-sm outline-none focus:ring-2 focus:ring-blue-500">
                                    <option value="all">Fin de Mes</option>
                                    {[...Array(new Date(adjustPeriod.anio, adjustPeriod.mes, 0).getDate())].map((_, i) => <option key={i+1} value={i+1}>Día {i+1}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="text-[10px] font-bold text-blue-500 block mb-1 uppercase tracking-widest">ID Periodo</label>
                                <select value={adjustPeriod.tipo} onChange={e => setAdjustPeriod({...adjustPeriod, tipo: parseInt(e.target.value)})} className="w-full border-2 border-blue-100 rounded-xl p-3 font-bold text-sm bg-blue-50 text-blue-700 outline-none focus:ring-2 focus:ring-blue-300">
                                    <option value={1}>1 (Q1)</option>
                                    <option value={2}>2 (Q2)</option>
                                    <option value={3}>3 (MC)</option>
                                </select>
                            </div>
                            <button onClick={calculateAdjustment} disabled={calculatingAdjust} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-xl flex items-center justify-center gap-2 transition-all h-[52px] shadow-lg shadow-blue-100 disabled:opacity-50">
                                {calculatingAdjust ? <Loader2 className="w-5 h-5 animate-spin" /> : <Play className="w-5 h-5" />}
                                Recalcular
                            </button>
                      </section>
                      
                      {/* Logs Viewer */}
                      {calculationLog.length > 0 && (
                          <div className="bg-slate-900 rounded-xl overflow-hidden shadow-md">
                              <button 
                                onClick={() => setShowLogs(!showLogs)}
                                className="w-full p-3 bg-slate-800 text-slate-300 text-xs font-mono flex items-center justify-between hover:bg-slate-700 transition-colors"
                              >
                                  <div className="flex items-center gap-2">
                                    <Terminal className="w-4 h-4" />
                                    <span>Log de Cálculo ({calculationLog.length} líneas)</span>
                                  </div>
                                  {showLogs ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                              </button>
                              {showLogs && (
                                  <div className="p-4 overflow-x-auto max-h-60 overflow-y-auto bg-slate-950 text-green-400 font-mono text-[10px] leading-relaxed whitespace-pre">
                                      {calculationLog.join('\n')}
                                  </div>
                              )}
                          </div>
                      )}

                      {adjustResult && (
                          <div className="animate-in fade-in slide-in-from-bottom-4 space-y-6">
                                
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-center items-center shadow-sm">
                                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Nuevo Valor Teórico</p>
                                        <p className="text-2xl font-black text-blue-600">{formatCurrency(theoreticalTotal)}</p>
                                    </div>
                                    <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 flex flex-col justify-center items-center shadow-sm">
                                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Valor Ya Liquidado</p>
                                        <p className="text-2xl font-black text-slate-400">-{formatCurrency(adjustingLiq.comision_total)}</p>
                                    </div>
                                    <div className="bg-orange-600 border border-orange-700 rounded-2xl p-5 flex flex-col justify-center items-center text-white shadow-xl shadow-orange-100">
                                        <p className="text-[10px] font-black text-orange-100 uppercase tracking-widest mb-1">Diferencia a Registrar</p>
                                        <p className="text-3xl font-black tracking-tighter">{formatCurrency(adjustResult.comision_total)}</p>
                                    </div>
                                </div>

                                <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-6 flex flex-col md:flex-row justify-between items-center gap-6">
                                    <div className="flex items-center gap-4 text-left">
                                        <div className="w-12 h-12 bg-green-200 rounded-full flex items-center justify-center text-green-700 shadow-inner">
                                            <Check className="w-6 h-6" />
                                        </div>
                                        <div>
                                            <p className="text-sm font-black text-green-800 uppercase tracking-tight">Listo para Guardar Ajuste</p>
                                            <p className="text-xs text-green-600">Se registrará un nuevo ID en el historial con el valor de la diferencia.</p>
                                        </div>
                                    </div>
                                    <button onClick={saveAdjustment} className="bg-green-600 hover:bg-green-700 text-white font-black py-4 px-10 rounded-xl flex items-center gap-3 shadow-xl shadow-green-200 transition-all active:scale-95 uppercase text-xs tracking-widest">
                                        <Save className="w-5 h-5" /> Guardar Nuevo Ajuste
                                    </button>
                                </div>

                                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                                     <div className="bg-slate-50 px-4 py-2 border-b text-[9px] font-black text-slate-400 uppercase tracking-widest">Desglose de Diferencias Aplicadas</div>
                                     <table className="w-full text-xs">
                                          <thead><tr className="text-slate-400 font-bold uppercase text-[9px] border-b"><th className="p-3 text-left">Concepto</th><th className="p-3 text-right">Venta (Diferencia)</th><th className="p-3 text-right">Monto de Ajuste</th></tr></thead>
                                          <tbody className="divide-y divide-slate-100">
                                              {adjustResult.detalles_conceptos.map((det, i) => (
                                                  <tr key={i} className="hover:bg-slate-50 transition-colors">
                                                      <td className="p-3 font-bold text-slate-700">{det.concepto}</td>
                                                      <td className={`p-3 text-right font-medium ${det.venta_total >= 0 ? 'text-slate-600' : 'text-red-500'}`}>
                                                          {formatCurrency(det.venta_total)}
                                                      </td>
                                                      <td className={`p-3 text-right font-black ${det.total_concepto >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                                                          {formatCurrency(det.total_concepto)}
                                                      </td>
                                                  </tr>
                                              ))}
                                          </tbody>
                                     </table>
                                </div>
                          </div>
                      )}
                  </div>
              </div>
          </div>
      )}
    </div>
  );
}
