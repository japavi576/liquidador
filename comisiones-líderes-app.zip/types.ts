
// Data Models
export type TipoParametrizacion = 
  | 'MANO DE OBRA'
  | 'REPUESTOS'
  | 'NPS VENTAS'
  | 'NPS POSVENTA'
  | 'IFC GM POSVENTA'
  | 'VENTAS PERSONALES'
  | 'NPS INTERNO'
  | 'REPUTATION'
  | 'PERMANENCIA'
  | 'CREACION'
  | 'EFECTIVIDAD'
  | 'MARGEN AYURAUTO POSVENTA';

export type ModoRegla = 'RANGOS' | 'META_UNICA';

export type OperadorRango = 'ENTRE' | 'MAYOR_IGUAL' | 'MENOR_IGUAL';

export interface RangoComision {
  operador: OperadorRango; // Comparison logic
  min: number | null;
  max: number | null; // null represents "Max" or Infinity
  meta: number | null; // Target Goal for this range
  porcentaje: number | null; // Commission %
  valor: number | null; // Fixed Value Payment
}

export interface MetaUnica {
  meta: number | null;
  porcentaje: number | null;
  valor: number | null; // Fixed Value Payment
}

export interface DetallesParametrizacion {
  modo: ModoRegla;
  rangos: RangoComision[];
  metaUnica: MetaUnica;
}

export interface ParametrizacionLiquidacion {
  tipo: TipoParametrizacion;
  // Map of segment names to details.
  // Standard types use 'GENERAL'. Segmented types use 'LIVIANOS', 'PESADOS', 'TODO'.
  segmentos: {
    [key: string]: DetallesParametrizacion; 
  };
}

export interface Persona {
  nit: string; // Used as ID (Cedula)
  nombre: string;
  bodegas: string[]; // List of Bodega IDs
  email?: string;
  parametrizacion?: ParametrizacionLiquidacion[];
}

export interface Venta {
  bodega: string;
  anio: number;
  mes: number;
  dia: number;
  tipo_venta: string;
  valor: number;
}

export interface DetalleConcepto {
  concepto: string; // e.g. "MANO DE OBRA"
  segmento_aplicado: string; // e.g. "TODO", "GENERAL"
  venta_total: number;
  meta_objetivo: number;
  porcentaje_cumplimiento: number;
  comision_porcentaje_aplicado: number;
  comision_valor_fijo_aplicado: number;
  total_concepto: number;
  mensaje?: string; // e.g. "Rango 90-100%"
}

export interface Liquidacion {
  id: string; // UUID (ID de Liquidación)
  periodo_id: number; // 1: Q1, 2: Q2, 3: MC
  fecha_calculo: string; // ISO String
  periodo: {
    anio: number;
    mes: number;
    dia: number | 'all';
  };
  persona_nit: string;
  persona_nombre: string;
  total_ventas: number;
  comision_total: number;
  detalles_conceptos: DetalleConcepto[];
  detalle_bodegas: {
    bodega: string;
    valor: number;
  }[];
  storagePath?: string; 
  es_ajuste?: boolean; 
  original_id?: string; 
}

// Auth State
export interface AuthState {
  isAuthenticated: boolean;
  user: {
    name: string;
    username: string;
  } | null;
  mode: 'local' | 'azure';
  accessToken?: string;
}

// Constants for Excel Columns
export const EXCEL_COLUMNS = [
  'bodega',
  'año',
  'mes',
  'día',
  'tipo_venta',
  'valor'
];
