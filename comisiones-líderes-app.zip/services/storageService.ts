
import { BlobServiceClient, ContainerClient } from "@azure/storage-blob";
import { Persona, Venta, Liquidacion } from "../types";

const STORAGE_ACCOUNT = "servernas";
const CONTAINER_NAME = "comisiones-lideres";
// Provided SAS Token (Long-lived until 2092)
const DEFAULT_SAS_TOKEN = "sp=racwdl&st=2026-02-11T13:43:53Z&se=2092-02-11T21:58:53Z&spr=https&sv=2024-11-04&sr=c&sig=q0dvjOzUj3Ul2LVWHbdLl1ZOdiIETH64GMtqujo5T%2F8%3D";

const LOCAL_STORAGE_KEY_PREFIX = "MOCK_BLOB_";

class MockStorage {
  upload(path: string, data: any) {
    localStorage.setItem(LOCAL_STORAGE_KEY_PREFIX + path, JSON.stringify(data));
  }

  async download<T>(path: string): Promise<T | null> {
    const item = localStorage.getItem(LOCAL_STORAGE_KEY_PREFIX + path);
    return item ? JSON.parse(item) as T : null;
  }

  async list(prefix: string): Promise<string[]> {
    return Object.keys(localStorage)
      .filter(k => k.startsWith(LOCAL_STORAGE_KEY_PREFIX + prefix))
      .map(k => k.replace(LOCAL_STORAGE_KEY_PREFIX, ''));
  }

  async delete(path: string): Promise<void> {
      localStorage.removeItem(LOCAL_STORAGE_KEY_PREFIX + path);
  }
}

const mockStore = new MockStorage();

export class AppStorageService {
  private mode: 'local' | 'azure';
  private sasToken: string;

  constructor(mode: 'local' | 'azure', sasToken?: string) {
    this.mode = mode;
    // Use provided token or fallback to the hardcoded default one
    this.sasToken = sasToken || DEFAULT_SAS_TOKEN;
  }

  private getContainerClient(): ContainerClient | null {
    if (this.mode === 'local') return null;
    
    // Ensure query string format
    const sas = this.sasToken.startsWith('?') ? this.sasToken : `?${this.sasToken}`;
    
    try {
        const blobServiceClient = new BlobServiceClient(
          `https://${STORAGE_ACCOUNT}.blob.core.windows.net${sas}`
        );
        return blobServiceClient.getContainerClient(CONTAINER_NAME);
    } catch (error) {
        console.error("Error creating Blob Client:", error);
        throw new Error("Configuración de Azure inválida");
    }
  }

  // New method to validate connection
  async validateConnection(): Promise<boolean> {
      if (this.mode === 'local') return true;
      try {
          const container = this.getContainerClient();
          if (!container) return false;
          // Try to check if container exists or list blobs (lightweight operation)
          await container.exists();
          return true;
      } catch (error) {
          console.error("Connection Validation Failed:", error);
          return false;
      }
  }

  async savePersona(persona: Persona): Promise<void> {
    const path = `personas/${persona.nit}/info.json`;
    if (this.mode === 'local') {
      mockStore.upload(path, persona);
    } else {
      const container = this.getContainerClient();
      if (!container) throw new Error("Azure Connection Failed");
      const blockBlobClient = container.getBlockBlobClient(path);
      const content = JSON.stringify(persona, null, 2);
      await blockBlobClient.upload(content, content.length, {
        blobHTTPHeaders: { blobContentType: "application/json" }
      });
    }
  }

  async getAllPersonas(): Promise<Persona[]> {
      const personas: Persona[] = [];
      if (this.mode === 'local') {
          const keys = await mockStore.list("personas/");
          for(const key of keys) {
              const p = await mockStore.download<Persona>(key);
              if(p) personas.push(p);
          }
      } else {
        const container = this.getContainerClient();
        if(container) {
            for await (const blob of container.listBlobsFlat({ prefix: 'personas/' })) {
                if(blob.name.endsWith('info.json')) {
                    const client = container.getBlobClient(blob.name);
                    const download = await client.download();
                    const text = await (await download.blobBody)?.text();
                    if(text) personas.push(JSON.parse(text));
                }
            }
        }
      }
      return personas;
  }

  async saveVentasBatch(ventas: Venta[], fileName: string): Promise<void> {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const archivePath = `cargas_ventas/${timestamp}_${fileName}.json`;
    
    // Group incoming sales by Year-Month
    const incomingByMonth: Record<string, Venta[]> = {};
    ventas.forEach(v => {
        const key = `${v.anio}-${v.mes}`;
        if (!incomingByMonth[key]) incomingByMonth[key] = [];
        incomingByMonth[key].push(v);
    });

    if (this.mode === 'local') {
       mockStore.upload(archivePath, ventas);
       
       const masterPath = `sistema/ventas_actuales.json`;
       let existing = await mockStore.download<Venta[]>(masterPath) || [];

       // For each month in incoming, intelligently merge
       for (const [key, batch] of Object.entries(incomingByMonth)) {
           const [y, m] = key.split('-').map(Number);
           const daysToUpdate = new Set(batch.map(v => v.dia));
           
           // Remove existing sales for this month AND these specific days
           existing = existing.filter(v => {
               if (v.anio === y && v.mes === m && daysToUpdate.has(v.dia)) return false;
               return true;
           });
           
           // Append new sales
           existing.push(...batch);
       }
       
       mockStore.upload(masterPath, existing);
    } else {
        const container = this.getContainerClient();
        if(container) {
            const data = JSON.stringify(ventas);
            await container.getBlockBlobClient(archivePath).upload(data, data.length);
            
            // Process per month group
            for(const [key, batch] of Object.entries(incomingByMonth)) {
                const [y, m] = key.split('-').map(Number);
                const blobPath = `ventas/${y}/${m}/data.json`;
                const client = container.getBlockBlobClient(blobPath);
                
                let currentMonthSales: Venta[] = [];
                // Check if blob exists and download current data
                if (await client.exists()) {
                     const dl = await client.download();
                     const text = await (await dl.blobBody)?.text();
                     if (text) {
                         try {
                            currentMonthSales = JSON.parse(text);
                         } catch (e) {
                             console.warn("Error parsing existing sales blob, starting fresh for month", blobPath);
                         }
                     }
                }

                // Identify days present in the new batch
                const daysToUpdate = new Set(batch.map(v => v.dia));

                // Filter out existing sales for those specific days (Replace logic per day)
                const cleanedSales = currentMonthSales.filter(v => !daysToUpdate.has(v.dia));
                
                // Merge
                const mergedSales = [...cleanedSales, ...batch];

                // Upload merged result
                const mergedData = JSON.stringify(mergedSales);
                await client.upload(mergedData, mergedData.length, {
                    blobHTTPHeaders: { blobContentType: "application/json" }
                });
            }
        }
    }
  }

  async saveLiquidacion(liq: Liquidacion): Promise<void> {
      const { anio, mes, dia } = liq.periodo;
      const diaStr = dia === 'all' ? 'mes_completo' : `dia_${dia}`;
      const fileName = `${liq.persona_nit}_${liq.id}.json`;
      const path = `liquidaciones/${anio}/${mes}/${diaStr}/${fileName}`;
      liq.storagePath = path;

      if (this.mode === 'local') {
        mockStore.upload(path, liq);
      } else {
        const container = this.getContainerClient();
        if(!container) throw new Error("Connection Error");
        const data = JSON.stringify(liq, null, 2);
        await container.getBlockBlobClient(path).upload(data, data.length, {
             blobHTTPHeaders: { blobContentType: "application/json" }
        });
      }
  }

  async listLiquidaciones(): Promise<Liquidacion[]> {
      const results: Liquidacion[] = [];
      if (this.mode === 'local') {
          const keys = await mockStore.list("liquidaciones/");
          for(const key of keys) {
              const liq = await mockStore.download<Liquidacion>(key);
              if(liq) {
                  liq.storagePath = key;
                  results.push(liq);
              }
          }
      } else {
          const container = this.getContainerClient();
          if(container) {
              for await (const blob of container.listBlobsFlat({ prefix: 'liquidaciones/' })) {
                  const client = container.getBlobClient(blob.name);
                  const dl = await client.download();
                  const text = await (await dl.blobBody)?.text();
                  if(text) {
                      try {
                        const liq: Liquidacion = JSON.parse(text);
                        liq.storagePath = blob.name;
                        results.push(liq);
                      } catch (e) {}
                  }
              }
          }
      }
      return results.sort((a,b) => b.fecha_calculo.localeCompare(a.fecha_calculo));
  }

  async deleteLiquidacion(liq: Liquidacion): Promise<void> {
      const path = liq.storagePath;
      if (!path) return;
      if (this.mode === 'local') {
          await mockStore.delete(path);
      } else {
          const container = this.getContainerClient();
          if(container) {
              const blobClient = container.getBlobClient(path);
              if (await blobClient.exists()) await blobClient.delete();
          }
      }
  }
  
  async getVentasForPeriod(anio: number, mes: number): Promise<Venta[]> {
      if(this.mode === 'local') {
          const all = await mockStore.download<Venta[]>('sistema/ventas_actuales.json') || [];
          return all.filter(v => Number(v.anio) === Number(anio) && Number(v.mes) === Number(mes));
      } else {
          const path = `ventas/${anio}/${mes}/data.json`;
          const container = this.getContainerClient();
          if(!container) return [];
          const client = container.getBlobClient(path);
          if(await client.exists()) {
              const dl = await client.download();
              const text = await (await dl.blobBody)?.text();
              return text ? JSON.parse(text) : [];
          }
          return [];
      }
  }
}
