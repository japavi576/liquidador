import React, { useState, useEffect } from 'react';
import { AppStorageService } from '../services/storageService';
import { Persona, Liquidacion, DetalleConcepto, Venta, DetallesParametrizacion, ParametrizacionLiquidacion } from '../types';
import { Play, Save, ChevronDown, ChevronRight, DollarSign, Target, Percent, AlertCircle, Info, CheckCircle, Calendar, Loader2, Hash, CalendarDays } from 'lucide-react';

// Numeric IDs: 1 (Q1), 2 (Q2), 3 (MC)
type PeriodoID = 1 | 2 | 3;

export default function CommissionCalculator({ storage }: { storage: AppStorageService }) {
  const [periodo, setPeriodo] = useState({ 
    anio: new Date().getFullYear(), 
    mes: new Date().getMonth() + 1,
    dia: 'all' as number | 'all',
    tipo: 3 as PeriodoID
  });
  const [liquidaciones, setLiquidaciones] = useState<Liquidacion[]>([]);
  const [processing, setProcessing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [statusMsg, setStatusMsg] = useState<{type: 'error' | 'warning' | 'success' | 'info', text: string} | null>(null);

  const daysInMonth = new Date(periodo.anio, periodo.mes, 0).getDate();

  const toggleRow = (id: string) => {
    const newSet = new Set(expandedRows);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setExpandedRows(newSet);
  };

  const normalize = (str: string) => {
      return str.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
  };

  const calculate = async () => {
    setProcessing(true);
    setLiquidaciones([]); 
    setStatusMsg(null);
    setExpandedRows(new Set());

    try {
        const personas = await storage.getAllPersonas();
        const ventasRaw = await storage.getVentasForPeriod(periodo.anio, periodo.mes);
        
        if (ventasRaw.length === 0) {
            setStatusMsg({ type: 'warning', text: `No se encontraron registros de ventas para el periodo seleccionado.` });
            setProcessing(false);
            return;
        }

        // --- AGGREGATION STEP: SUM BY KEY TO PREVENT DOUBLE COUNTING ---
        const aggregatedMap = new Map<string, Venta>();
        
        ventasRaw.forEach(v => {
            const key = `${v.bodega}-${v.anio}-${v.mes}-${v.dia}-${normalize(v.tipo_venta)}`;
            if (aggregatedMap.has(key)) {
                aggregatedMap.get(key)!.valor += v.valor;
            } else {
                aggregatedMap.set(key, { ...v });
            }
        });

        const collapsedVentas = Array.from(aggregatedMap.values());

        // --- FILTER STEP: APPLY CUT-OFF DAY ---
        let filteredVentas = collapsedVentas;
        if (periodo.dia !== 'all') {
            const diaCorte = Number(periodo.dia);
            filteredVentas = collapsedVentas.filter(v => Number(v.dia) <= diaCorte);
        }

        const results: Liquidacion[] = [];

        for (const p of personas) {
            if (!p.parametrizacion || p.parametrizacion.length === 0) continue;

            const pBodegas = p.bodegas.map(b => normalize(b));
            const personSales = filteredVentas.filter(v => pBodegas.includes(normalize(String(v.bodega))));
            
            if (personSales.length === 0) continue;
            
            let totalComisionPersona = 0;
            let totalVentasPersona = 0;
            const conceptos: DetalleConcepto[] = [];
            const bodegaMap: Record<string, number> = {};

            // Calculate base sums for the leader
            personSales.forEach(v => {
                bodegaMap[v.bodega] = (bodegaMap[v.bodega] || 0) + v.valor;
                totalVentasPersona += v.valor;
            });

            for (const param of p.parametrizacion) {
                const paramTipoNorm = normalize(param.tipo);
                const salesForType = personSales.filter(v => normalize(v.tipo_venta).includes(paramTipoNorm));
                const ventaTotalConcepto = salesForType.reduce((sum, v) => sum + v.valor, 0);

                let detalles: DetallesParametrizacion | null = null;
                let segmentoUsado = '';

                const hasMeta = (d: DetallesParametrizacion) => {
                    if (d.modo === 'META_UNICA') return (d.metaUnica.meta || 0) > 0;
                    if (d.modo === 'RANGOS') return d.rangos.some(r => (r.meta || 0) > 0);
                    return false;
                };

                if (param.segmentos['TODO'] && hasMeta(param.segmentos['TODO'])) { detalles = param.segmentos['TODO']; segmentoUsado = 'TODO'; } 
                else if (param.segmentos['GENERAL'] && hasMeta(param.segmentos['GENERAL'])) { detalles = param.segmentos['GENERAL']; segmentoUsado = 'GENERAL'; }
                else {
                    const keys = Object.keys(param.segmentos);
                    const validKey = keys.find(k => hasMeta(param.segmentos[k]));
                    if (validKey) { detalles = param.segmentos[validKey]; segmentoUsado = validKey; }
                    else if (keys.length > 0) { detalles = param.segmentos[keys[0]]; segmentoUsado = keys[0]; }
                }

                if (!detalles) continue;

                let comisionGenerada = 0;
                let metaObjetivo = 0;
                let porcentajeCumplimiento = 0;
                let mensaje = '';

                if (detalles.modo === 'META_UNICA') {
                    metaObjetivo = detalles.metaUnica.meta || 0;
                    porcentajeCumplimiento = metaObjetivo > 0 ? (ventaTotalConcepto / metaObjetivo) * 100 : 0;
                    if (ventaTotalConcepto >= metaObjetivo) {
                        comisionGenerada = (ventaTotalConcepto * ((detalles.metaUnica.porcentaje || 0) / 100)) + (detalles.metaUnica.valor || 0);
                        mensaje = `Meta Alcanzada`;
                    }
                } else {
                    const rangoConMeta = detalles.rangos.find(r => r.meta !== null && r.meta > 0);
                    metaObjetivo = rangoConMeta ? (rangoConMeta.meta || 0) : 0;
                    porcentajeCumplimiento = metaObjetivo > 0 ? (ventaTotalConcepto / metaObjetivo) * 100 : 0;
                    
                    const matchedRange = detalles.rangos.find(r => {
                        const min = r.min !== null ? r.min : -Infinity;
                        const max = r.max !== null ? r.max : Infinity;
                        if (r.operador === 'ENTRE') return porcentajeCumplimiento >= min && porcentajeCumplimiento <= max;
                        if (r.operador === 'MAYOR_IGUAL') return porcentajeCumplimiento >= min;
                        if (r.operador === 'MENOR_IGUAL') return porcentajeCumplimiento <= max;
                        return false;
                    });
                    
                    if (matchedRange) {
                        comisionGenerada = (ventaTotalConcepto * ((matchedRange.porcentaje || 0) / 100)) + (matchedRange.valor || 0);
                        mensaje = `${matchedRange.operador}`;
                    }
                }

                totalComisionPersona += comisionGenerada;
                conceptos.push({
                    concepto: param.tipo,
                    segmento_aplicado: segmentoUsado,
                    venta_total: ventaTotalConcepto,
                    meta_objetivo: metaObjetivo,
                    porcentaje_cumplimiento: porcentajeCumplimiento,
                    comision_porcentaje_aplicado: 0,
                    comision_valor_fijo_aplicado: 0,
                    total_concepto: comisionGenerada,
                    mensaje
                });
            }

            if (conceptos.length > 0) {
                results.push({
                    id: crypto.randomUUID(), 
                    periodo_id: periodo.tipo, 
                    fecha_calculo: new Date().toISOString(),
                    periodo: { anio: periodo.anio, mes: periodo.mes, dia: periodo.dia },
                    persona_nit: p.nit,
                    persona_nombre: p.nombre,
                    total_ventas: totalVentasPersona,
                    comision_total: totalComisionPersona,
                    detalles_conceptos: conceptos,
                    detalle_bodegas: Object.entries(bodegaMap).map(([b, v]) => ({ bodega: b, valor: v }))
                });
            }
        }
        
        setStatusMsg({ type: 'success', text: `¡Proceso exitoso! Se liquidaron ${results.length} líderes.` });
        setLiquidaciones(results);
    } catch (e: any) {
        setStatusMsg({ type: 'error', text: "Error: " + e.message });
    } finally {
        setProcessing(false);
    }
  };

  const saveAll = async () => {
      setSaving(true);
      try {
          for(const liq of liquidaciones) await storage.saveLiquidacion(liq);
          setStatusMsg({ type: 'success', text: "Las liquidaciones se guardaron en el historial." });
          setLiquidaciones([]);
      } catch(e: any) { 
          setStatusMsg({ type: 'error', text: "Error al guardar." });
      } finally { setSaving(false); }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-800">Liquidación de Comisiones</h2>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
         <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
            <div className="md:col-span-2">
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Año</label>
                <input type="number" value={periodo.anio} onChange={e => setPeriodo({...periodo, anio: parseInt(e.target.value)})} className="w-full border border-slate-300 rounded-lg p-2.5 text-sm font-bold" />
            </div>
            <div className="md:col-span-2">
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Mes</label>
                <select value={periodo.mes} onChange={e => setPeriodo({...periodo, mes: parseInt(e.target.value)})} className="w-full border border-slate-300 rounded-lg p-2.5 text-sm font-bold">
                    {[...Array(12)].map((_, i) => <option key={i+1} value={i+1}>{new Date(0, i).toLocaleString('es', { month: 'long' })}</option>)}
                </select>
            </div>
            <div className="md:col-span-2">
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Día Corte (Hasta)</label>
                <select value={periodo.dia} onChange={e => setPeriodo({...periodo, dia: e.target.value === 'all' ? 'all' : parseInt(e.target.value)})} className="w-full border border-slate-300 rounded-lg p-2.5 text-sm font-bold">
                    <option value="all">Fin de Mes</option>
                    {[...Array(daysInMonth)].map((_, i) => <option key={i+1} value={i+1}>Día {i+1}</option>)}
                </select>
            </div>
            <div className="md:col-span-3">
                <label className="block text-[10px] font-bold text-blue-500 uppercase mb-1">ID Periodo Liquidación</label>
                <select value={periodo.tipo} onChange={e => setPeriodo({...periodo, tipo: parseInt(e.target.value) as PeriodoID})} className="w-full border-2 border-blue-100 rounded-lg p-2.5 text-sm font-bold bg-blue-50 text-blue-700">
                    <option value={1}>1 (Primera Quincena)</option>
                    <option value={2}>2 (Segunda Quincena)</option>
                    <option value={3}>3 (Mes Completo)</option>
                </select>
            </div>
            <div className="md:col-span-3">
                <button onClick={calculate} disabled={processing} className="w-full bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-lg flex items-center justify-center gap-2 font-bold h-[44px] shadow-lg disabled:opacity-50">
                    {processing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Play className="w-5 h-5" />}
                    Calcular Liquidación
                </button>
            </div>
         </div>
      </div>

      {statusMsg && (
          <div className={`p-4 rounded-xl border flex items-start gap-3 animate-in fade-in slide-in-from-top-2 ${statusMsg.type === 'error' ? 'bg-red-50 text-red-700 border-red-100' : 'bg-green-50 text-green-700 border-green-100'}`}>
              <Info className="w-5 h-5 shrink-0" />
              <p className="text-sm font-medium">{statusMsg.text}</p>
          </div>
      )}

      {liquidaciones.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-slate-50">
                  <div className="flex items-center gap-2">
                      <CalendarDays className="w-5 h-5 text-blue-600" />
                      <h3 className="font-bold text-slate-700 text-xs uppercase">Previsualización Periodo {periodo.tipo}</h3>
                  </div>
                  <button onClick={saveAll} disabled={saving} className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg text-xs font-black shadow-md disabled:opacity-50 transition-all">
                      {saving ? "Guardando..." : "Confirmar y Guardar"}
                  </button>
              </div>
              <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                      <thead className="bg-slate-100 text-slate-600 uppercase text-[9px] font-bold">
                          <tr>
                              <th className="p-3 w-8"></th>
                              <th className="p-3">ID Liquidación</th>
                              <th className="p-3">Año</th>
                              <th className="p-3">Mes</th>
                              <th className="p-3 text-center">ID Per.</th>
                              <th className="p-3">Líder</th>
                              <th className="p-3 text-right">Comisión</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {liquidaciones.map(liq => (
                              <React.Fragment key={liq.id}>
                                  <tr className="hover:bg-slate-50 cursor-pointer transition-colors" onClick={() => toggleRow(liq.id)}>
                                      <td className="p-3 text-center">{expandedRows.has(liq.id) ? <ChevronDown className="w-4 h-4 text-blue-500" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}</td>
                                      <td className="p-3 font-mono text-[10px] text-slate-500">{liq.id.substring(0, 8)}</td>
                                      <td className="p-3 text-slate-600">{liq.periodo.anio}</td>
                                      <td className="p-3 text-slate-600 capitalize">{new Date(0, liq.periodo.mes-1).toLocaleString('es', { month: 'long' })}</td>
                                      <td className="p-3 text-center"><span className="bg-blue-600 text-white px-3 py-1 rounded-full text-[10px] font-black">{liq.periodo_id}</span></td>
                                      <td className="p-3 font-bold text-slate-800">{liq.persona_nombre}</td>
                                      <td className="p-3 text-right font-black text-green-600 text-lg tracking-tighter">${liq.comision_total.toLocaleString()}</td>
                                  </tr>
                                  {expandedRows.has(liq.id) && (
                                      <tr><td colSpan={7} className="bg-slate-50 p-4">
                                          <div className="bg-white rounded-lg border p-4 shadow-sm text-xs animate-in slide-in-from-top-1">
                                              <div className="text-[9px] font-black text-slate-400 mb-3 uppercase tracking-widest">Desglose de Conceptos</div>
                                              <table className="w-full">
                                                  <thead><tr className="text-slate-400 uppercase text-[9px] font-bold"><th className="p-2 text-left">Concepto</th><th className="p-2 text-right">Venta</th><th className="p-2 text-right">Meta</th><th className="p-2 text-right">Comisión</th></tr></thead>
                                                  <tbody className="divide-y divide-slate-100">
                                                      {liq.detalles_conceptos.map((det, idx) => (
                                                          <tr key={idx}><td className="p-2 font-bold text-slate-700">{det.concepto}</td><td className="p-2 text-right">${det.venta_total.toLocaleString()}</td><td className="p-2 text-right">${det.meta_objetivo.toLocaleString()}</td><td className="p-2 text-right font-black text-green-700">${det.total_concepto.toLocaleString()}</td></tr>
                                                      ))}
                                                  </tbody>
                                              </table>
                                          </div>
                                      </td></tr>
                                  )}
                              </React.Fragment>
                          ))}
                      </tbody>
                  </table>
              </div>
          </div>
      )}
    </div>
  );
}
