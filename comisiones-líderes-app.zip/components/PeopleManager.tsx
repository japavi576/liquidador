import React, { useState, useEffect } from 'react';
import { AppStorageService } from '../services/storageService';
import { Persona, TipoParametrizacion, ParametrizacionLiquidacion, DetallesParametrizacion, RangoComision } from '../types';
import { Plus, Save, User, Settings, Trash2, List, Target, X, Truck, Car, DollarSign, Percent, ArrowRight, Layers, Copy } from 'lucide-react';

const TIPOS_PARAMETRIZACION: TipoParametrizacion[] = [
  'MANO DE OBRA', 
  'REPUESTOS', 
  'NPS VENTAS', 
  'NPS POSVENTA', 
  'IFC GM POSVENTA', 
  'VENTAS PERSONALES', 
  'NPS INTERNO', 
  'REPUTATION', 
  'PERMANENCIA', 
  'CREACION', 
  'EFECTIVIDAD', 
  'MARGEN AYURAUTO POSVENTA'
];

const SEGMENTED_TYPES: TipoParametrizacion[] = ['REPUESTOS', 'NPS POSVENTA'];

const DEFAULT_DETALLES: DetallesParametrizacion = {
  modo: 'RANGOS',
  rangos: [{ operador: 'ENTRE', min: null, max: null, meta: null, porcentaje: null, valor: null }],
  metaUnica: { meta: null, porcentaje: null, valor: null }
};

// --- Custom Input Components ---

const CurrencyInput = ({ value, onChange, placeholder, className }: { value: number | null, onChange: (val: number | null) => void, placeholder?: string, className?: string }) => {
    const [display, setDisplay] = useState('');
    const [focused, setFocused] = useState(false);

    useEffect(() => {
        if (!focused) {
            if (value === null || value === undefined || value === 0 && display === '') {
                setDisplay('');
            } else {
                // Format as currency when not focused
                setDisplay(new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 2 }).format(value));
            }
        }
    }, [value, focused]); // eslint-disable-line

    const handleFocus = () => {
        setFocused(true);
        // Show raw number for editing
        setDisplay(value === null || value === undefined ? '' : value.toString());
    };

    const handleBlur = () => {
        setFocused(false);
        // Effect will re-run and format
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = e.target.value;
        // Allow digits and one dot for decimal
        if (/^\d*\.?\d*$/.test(val)) {
            setDisplay(val);
            if (val === '' || val === '.') {
                onChange(null);
            } else {
                onChange(parseFloat(val));
            }
        }
    };

    return (
        <input
            type="text"
            value={display}
            onChange={handleChange}
            onFocus={handleFocus}
            onBlur={handleBlur}
            placeholder={placeholder}
            className={className}
        />
    );
};

const DecimalInput = ({ value, onChange, placeholder, className, alignRight = false }: { value: number | null, onChange: (val: number | null) => void, placeholder?: string, className?: string, alignRight?: boolean }) => {
    const [display, setDisplay] = useState('');

    useEffect(() => {
        // Only update from prop if the parsed value matches (avoids cursor jumps/format fights while typing "1.")
        if (value === null || value === undefined) {
             if (display !== '') setDisplay('');
        } else {
             const parsedDisplay = parseFloat(display);
             if (parsedDisplay !== value) {
                 setDisplay(value.toString());
             }
        }
    }, [value]); // eslint-disable-line

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = e.target.value;
        // Regex to allow generic float input (including "0.")
        if (/^\d*\.?\d*$/.test(val)) {
            setDisplay(val);
            if (val === '' || val === '.') {
                onChange(null);
            } else {
                onChange(parseFloat(val));
            }
        }
    };

    return (
        <input
            type="text"
            value={display}
            onChange={handleChange}
            placeholder={placeholder}
            className={`${className} ${alignRight ? 'text-right' : 'text-center'}`}
            inputMode="decimal"
        />
    );
};


export default function PeopleManager({ storage }: { storage: AppStorageService }) {
  const [personas, setPersonas] = useState<Persona[]>([]);
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState<Partial<Persona>>({});
  const [isNew, setIsNew] = useState(false);
  const [bodegaInput, setBodegaInput] = useState('');
  
  // State for the selected parametrization type (Active Tab)
  const [selectedParamType, setSelectedParamType] = useState<string>('');
  const [activeSegment, setActiveSegment] = useState<string>('GENERAL');

  // State to show the "Add New" dropdown
  const [showAddType, setShowAddType] = useState(false);

  const loadPersonas = async () => {
    setLoading(true);
    const data = await storage.getAllPersonas();
    setPersonas(data);
    setLoading(false);
  };

  useEffect(() => {
    loadPersonas();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleEdit = (p: Persona) => {
    setEditing({ ...p });
    setIsNew(false);
    // Select the first param type if exists
    if (p.parametrizacion && p.parametrizacion.length > 0) {
        selectType(p.parametrizacion[0].tipo);
    } else {
        setSelectedParamType('');
    }
    setShowAddType(false);
  };

  const handleDuplicate = (p: Persona) => {
    // Deep clone to avoid mutations and clear unique identifier
    const clonedPersona: Partial<Persona> = JSON.parse(JSON.stringify(p));
    clonedPersona.nit = ''; // NIT must be unique
    clonedPersona.nombre = `${p.nombre} (Copia)`;
    
    setEditing(clonedPersona);
    setIsNew(true); // Treat as new because we need a new NIT
    
    // Select the first param type if exists
    if (clonedPersona.parametrizacion && clonedPersona.parametrizacion.length > 0) {
        selectType(clonedPersona.parametrizacion[0].tipo);
    } else {
        setSelectedParamType('');
    }
    setShowAddType(false);
  };

  const handleNew = () => {
    setEditing({ nit: '', nombre: '', bodegas: [], parametrizacion: [] });
    setIsNew(true);
    setSelectedParamType('');
    setShowAddType(false);
  };

  const selectType = (tipo: string) => {
      setSelectedParamType(tipo);
      // Determine default segment
      if (SEGMENTED_TYPES.includes(tipo as TipoParametrizacion)) {
          setActiveSegment('LIVIANOS');
      } else {
          setActiveSegment('GENERAL');
      }
  };

  const handleSave = async () => {
    if (!editing.nit || !editing.nombre) {
      alert("NIT y Nombre son obligatorios");
      return;
    }
    setLoading(true);
    const p: Persona = {
      nit: editing.nit,
      nombre: editing.nombre,
      bodegas: editing.bodegas || [],
      email: editing.email,
      parametrizacion: editing.parametrizacion || []
    };
    try {
      await storage.savePersona(p);
      setEditing({});
      setIsNew(false);
      setSelectedParamType('');
      await loadPersonas();
      alert("Guardado correctamente");
    } catch (e) {
      console.error(e);
      alert("Error al guardar");
    } finally {
      setLoading(false);
    }
  };

  const addBodega = () => {
    if(!bodegaInput) return;
    setEditing(prev => ({
        ...prev,
        bodegas: [...(prev.bodegas || []), bodegaInput]
    }));
    setBodegaInput('');
  }

  const removeBodega = (b: string) => {
    setEditing(prev => ({
        ...prev,
        bodegas: (prev.bodegas || []).filter(x => x !== b)
    }));
  }

  const handleAddType = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const type = e.target.value as TipoParametrizacion;
      if (!type) return;

      const currentParams = editing.parametrizacion || [];
      const exists = currentParams.find(p => p.tipo === type);
      
      if (!exists) {
          const isSegmented = SEGMENTED_TYPES.includes(type);
          const initialSegmentos: Record<string, DetallesParametrizacion> = {};
          
          if (isSegmented) {
              initialSegmentos['LIVIANOS'] = JSON.parse(JSON.stringify(DEFAULT_DETALLES));
              initialSegmentos['PESADOS'] = JSON.parse(JSON.stringify(DEFAULT_DETALLES));
              initialSegmentos['TODO'] = JSON.parse(JSON.stringify(DEFAULT_DETALLES));
          } else {
              initialSegmentos['GENERAL'] = JSON.parse(JSON.stringify(DEFAULT_DETALLES));
          }

          const newParam: ParametrizacionLiquidacion = { 
              tipo: type, 
              segmentos: initialSegmentos
          };
          setEditing(prev => ({
              ...prev,
              parametrizacion: [...(prev.parametrizacion || []), newParam]
          }));
          
          // Select immediately
          setSelectedParamType(type);
          setActiveSegment(isSegmented ? 'LIVIANOS' : 'GENERAL');
      } else {
          selectType(type);
      }
      
      setShowAddType(false);
  };

  const removeParametrizacion = (tipo: TipoParametrizacion) => {
      const newParams = (editing.parametrizacion || []).filter(p => p.tipo !== tipo);
      setEditing(prev => ({
          ...prev,
          parametrizacion: newParams
      }));
      
      if (selectedParamType === tipo) {
          if (newParams.length > 0) {
              selectType(newParams[0].tipo);
          } else {
              setSelectedParamType('');
          }
      }
  };

  // --- Helpers for Parametrization Logic ---

  const getCurrentParamDetails = (): DetallesParametrizacion | null => {
      if (!selectedParamType || !editing.parametrizacion) return null;
      const param = editing.parametrizacion.find(p => p.tipo === selectedParamType);
      return param?.segmentos[activeSegment] || null;
  };

  const updateParamDetails = (newDetails: Partial<DetallesParametrizacion>) => {
      setEditing(prev => {
          const params = [...(prev.parametrizacion || [])];
          const index = params.findIndex(p => p.tipo === selectedParamType);
          if (index > -1) {
              // Deep copy segments to avoid mutation
              const currentSegments = { ...params[index].segmentos };
              
              if (currentSegments[activeSegment]) {
                   currentSegments[activeSegment] = {
                       ...currentSegments[activeSegment],
                       ...newDetails
                   };
              }

              params[index] = {
                  ...params[index],
                  segmentos: currentSegments
              };
          }
          return { ...prev, parametrizacion: params };
      });
  };

  const updateRango = (index: number, field: keyof RangoComision, value: any) => {
     const current = getCurrentParamDetails();
     if (!current) return;
     const newRangos = [...current.rangos];
     newRangos[index] = { ...newRangos[index], [field]: value };
     updateParamDetails({ rangos: newRangos });
  };

  const addRango = () => {
      const current = getCurrentParamDetails();
      if (!current) return;
      
      // Get meta from first range if available
      const firstMeta = current.rangos.length > 0 ? current.rangos[0].meta : null;
      
      updateParamDetails({ 
          rangos: [...current.rangos, { operador: 'ENTRE', min: null, max: null, meta: firstMeta, porcentaje: null, valor: null }] 
      });
  };

  const deleteRango = (index: number) => {
      const current = getCurrentParamDetails();
      if (!current) return;
      updateParamDetails({ 
          rangos: current.rangos.filter((_, i) => i !== index) 
      });
  };

  const currentDetails = getCurrentParamDetails();
  const availableTypes = TIPOS_PARAMETRIZACION.filter(t => !editing.parametrizacion?.some(p => p.tipo === t));
  const isSegmentedType = SEGMENTED_TYPES.includes(selectedParamType as TipoParametrizacion);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800">Gestión de Líderes</h2>
        <button onClick={handleNew} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
            <Plus className="w-4 h-4" /> Nuevo Líder
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* List */}
        <div className="lg:col-span-1 bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-4 border-b border-slate-100 bg-slate-50">
                <h3 className="font-semibold text-slate-700">Listado</h3>
            </div>
            <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto">
                {loading && <div className="p-4 text-center text-slate-400">Cargando...</div>}
                {!loading && personas.length === 0 && <div className="p-4 text-center text-slate-400">No hay registros</div>}
                {personas.map(p => (
                    <div 
                        key={p.nit} 
                        className={`p-4 cursor-pointer hover:bg-blue-50 transition-colors group relative ${editing.nit === p.nit ? 'bg-blue-50 border-l-4 border-blue-500' : ''}`}
                        onClick={() => handleEdit(p)}
                    >
                        <div className="flex justify-between items-start">
                            <div>
                                <div className="font-medium text-slate-800">{p.nombre}</div>
                                <div className="text-xs text-slate-500">CC/NIT: {p.nit}</div>
                            </div>
                            <button 
                                onClick={(e) => { e.stopPropagation(); handleDuplicate(p); }}
                                title="Replicar parámetros de este líder"
                                className="opacity-0 group-hover:opacity-100 p-2 text-blue-500 hover:bg-blue-100 rounded-lg transition-all"
                            >
                                <Copy className="w-4 h-4" />
                            </button>
                        </div>
                        <div className="flex gap-2 mt-2 flex-wrap">
                             <span className="text-xs bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">{p.bodegas.length} bodegas</span>
                             {p.parametrizacion && p.parametrizacion.length > 0 && (
                                 <span className="text-xs bg-green-100 text-green-700 px-1.5 py-0.5 rounded">{p.parametrizacion.length} reglas</span>
                             )}
                        </div>
                    </div>
                ))}
            </div>
        </div>

        {/* Form */}
        <div className="lg:col-span-2">
            {editing.nit !== undefined ? (
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 flex flex-col h-full max-h-[800px] overflow-y-auto">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-lg font-bold text-slate-700">{isNew ? (editing.nombre?.includes('(Copia)') ? 'Replicando Líder' : 'Crear Nuevo') : 'Editar Líder'}</h3>
                        <button onClick={handleSave} disabled={loading} className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded flex items-center gap-2">
                            <Save className="w-4 h-4" /> Guardar
                        </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Cédula / NIT</label>
                            <input 
                                type="text" 
                                value={editing.nit} 
                                onChange={e => setEditing({...editing, nit: e.target.value})}
                                disabled={!isNew}
                                placeholder="Ingrese nuevo NIT"
                                className="w-full border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none disabled:bg-slate-100"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Nombre Completo</label>
                            <input 
                                type="text" 
                                value={editing.nombre} 
                                onChange={e => setEditing({...editing, nombre: e.target.value})}
                                className="w-full border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                            />
                        </div>
                    </div>

                    <div className="mb-6">
                         <label className="block text-sm font-medium text-slate-700 mb-2">Bodegas Asignadas</label>
                         <div className="flex gap-2 mb-3">
                             <input 
                                type="text" 
                                placeholder="Código de bodega (ej. B001)"
                                value={bodegaInput}
                                onChange={e => setBodegaInput(e.target.value)}
                                className="flex-1 border border-slate-300 rounded-lg p-2 text-sm"
                             />
                             <button onClick={addBodega} type="button" className="bg-slate-200 hover:bg-slate-300 text-slate-700 px-4 rounded-lg text-sm font-medium">Agregar</button>
                         </div>
                         <div className="flex flex-wrap gap-2">
                             {(editing.bodegas || []).map(b => (
                                 <span key={b} className="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full flex items-center gap-2">
                                     {b}
                                     <button onClick={() => removeBodega(b)} className="hover:text-red-500">×</button>
                                 </span>
                             ))}
                         </div>
                    </div>

                    <div className="border-t border-slate-100 pt-6 flex-1 flex flex-col">
                        <div className="flex items-center gap-2 mb-4">
                            <Settings className="w-5 h-5 text-slate-500" />
                            <h4 className="font-bold text-slate-700">Parametrización de Liquidación</h4>
                        </div>
                        
                        {/* Type Tabs */}
                        <div className="flex flex-wrap gap-2 mb-4 items-center">
                            {editing.parametrizacion?.map(p => (
                                <button 
                                    key={p.tipo}
                                    onClick={() => selectType(p.tipo)}
                                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-2 ${selectedParamType === p.tipo ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                                >
                                    {p.tipo}
                                    {selectedParamType === p.tipo && (
                                        <div 
                                            onClick={(e) => { e.stopPropagation(); removeParametrizacion(p.tipo as TipoParametrizacion); }}
                                            className="bg-blue-500 hover:bg-blue-700 rounded-full p-0.5"
                                        >
                                            <X className="w-3 h-3" />
                                        </div>
                                    )}
                                </button>
                            ))}

                            <div className="relative">
                                {!showAddType ? (
                                    <button 
                                        onClick={() => setShowAddType(true)}
                                        className="px-3 py-2 rounded-full text-sm font-medium border border-dashed border-slate-300 text-slate-500 hover:border-blue-400 hover:text-blue-600 flex items-center gap-1 transition-colors"
                                    >
                                        <Plus className="w-4 h-4" /> Agregar
                                    </button>
                                ) : (
                                    <div className="animate-in fade-in zoom-in duration-200">
                                        <select 
                                            autoFocus
                                            onBlur={() => setShowAddType(false)}
                                            onChange={handleAddType}
                                            value=""
                                            className="border border-blue-400 rounded-lg p-2 text-sm outline-none bg-white shadow-lg w-48"
                                        >
                                            <option value="">-- Seleccionar --</option>
                                            {availableTypes.map(t => (
                                                <option key={t} value={t}>{t}</option>
                                            ))}
                                            {availableTypes.length === 0 && <option disabled>Todos los tipos asignados</option>}
                                        </select>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Content Config */}
                        <div className="flex-1 bg-slate-50 p-4 rounded-xl border border-slate-200 overflow-hidden">
                            {selectedParamType && currentDetails ? (
                                <div className="animate-in fade-in slide-in-from-right-4 h-full flex flex-col">
                                    
                                    {/* Config Header */}
                                    <div className="flex flex-col gap-4 mb-4">
                                        <div className="flex justify-between items-center">
                                            <div className="flex items-center gap-3">
                                                <div className="bg-white p-2 rounded-lg border border-slate-200 shadow-sm">
                                                    {isSegmentedType ? <Truck className="w-5 h-5 text-blue-500" /> : <Settings className="w-5 h-5 text-slate-500" />}
                                                </div>
                                                <div>
                                                    <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Configurando</div>
                                                    <h2 className="text-lg font-bold text-slate-800 leading-none">{selectedParamType}</h2>
                                                </div>
                                            </div>

                                            {/* Mode Toggle */}
                                            <div className="flex bg-white p-1 rounded-lg border border-slate-200 shadow-sm">
                                                <button 
                                                    onClick={() => updateParamDetails({ modo: 'RANGOS' })}
                                                    className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${currentDetails.modo === 'RANGOS' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
                                                >
                                                    <List className="w-4 h-4" /> Rangos
                                                </button>
                                                <div className="w-px bg-slate-200 mx-1"></div>
                                                <button 
                                                    onClick={() => updateParamDetails({ modo: 'META_UNICA' })}
                                                    className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${currentDetails.modo === 'META_UNICA' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
                                                >
                                                    <Target className="w-4 h-4" /> Meta Única
                                                </button>
                                            </div>
                                        </div>

                                        {/* Sub Tabs for Segments */}
                                        {isSegmentedType && (
                                            <div className="flex border-b border-slate-200">
                                                <button
                                                    onClick={() => setActiveSegment('LIVIANOS')}
                                                    className={`px-4 py-2 text-sm font-medium flex items-center gap-2 border-b-2 transition-colors ${activeSegment === 'LIVIANOS' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
                                                >
                                                    <Car className="w-4 h-4" /> LIVIANOS
                                                </button>
                                                <button
                                                    onClick={() => setActiveSegment('PESADOS')}
                                                    className={`px-4 py-2 text-sm font-medium flex items-center gap-2 border-b-2 transition-colors ${activeSegment === 'PESADOS' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
                                                >
                                                    <Truck className="w-4 h-4" /> PESADOS
                                                </button>
                                                <button
                                                    onClick={() => setActiveSegment('TODO')}
                                                    className={`px-4 py-2 text-sm font-medium flex items-center gap-2 border-b-2 transition-colors ${activeSegment === 'TODO' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
                                                >
                                                    <Layers className="w-4 h-4" /> TODO
                                                </button>
                                            </div>
                                        )}
                                    </div>

                                    {/* Config Body */}
                                    <div className="overflow-y-auto flex-1 pr-2">
                                        {currentDetails.modo === 'RANGOS' && (
                                            <div className="grid grid-cols-1 gap-4">
                                                <div className="grid grid-cols-12 gap-2 text-[10px] text-slate-400 font-bold uppercase tracking-wider px-2">
                                                    <div className="col-span-4">Rango de Cumplimiento</div>
                                                    <div className="col-span-3">Meta Objetivo</div>
                                                    <div className="col-span-2">% Comisión</div>
                                                    <div className="col-span-2">Pago Fijo</div>
                                                    <div className="col-span-1"></div>
                                                </div>
                                                {currentDetails.rangos.map((rango, idx) => (
                                                    <div key={idx} className="bg-white border border-slate-200 rounded-xl p-3 grid grid-cols-12 items-center gap-2 shadow-sm group">
                                                        
                                                        {/* Rango Logic */}
                                                        <div className="col-span-4 flex flex-col gap-2">
                                                            <select
                                                                value={rango.operador || 'ENTRE'}
                                                                onChange={(e) => updateRango(idx, 'operador', e.target.value)}
                                                                className="w-full text-xs p-1 border border-slate-200 rounded outline-none focus:border-blue-400 bg-slate-50 text-slate-600"
                                                            >
                                                                <option value="ENTRE">Entre (Min - Max)</option>
                                                                <option value="MAYOR_IGUAL">Mayor o igual (&ge;)</option>
                                                                <option value="MENOR_IGUAL">Menor o igual (&le;)</option>
                                                            </select>
                                                            <div className="flex items-center gap-1">
                                                                {(rango.operador === 'ENTRE' || rango.operador === 'MAYOR_IGUAL' || !rango.operador) && (
                                                                     <DecimalInput 
                                                                        value={rango.min}
                                                                        onChange={(val) => updateRango(idx, 'min', val)}
                                                                        placeholder={rango.operador === 'MAYOR_IGUAL' ? 'Valor' : 'Min'}
                                                                        className="w-full p-1.5 border border-slate-200 rounded text-sm outline-none focus:border-blue-400"
                                                                    />
                                                                )}
                                                                
                                                                {(!rango.operador || rango.operador === 'ENTRE') && (
                                                                    <span className="text-slate-300 text-xs"><ArrowRight className="w-3 h-3"/></span>
                                                                )}

                                                                {(!rango.operador || rango.operador === 'ENTRE' || rango.operador === 'MENOR_IGUAL') && (
                                                                    <DecimalInput 
                                                                        value={rango.max}
                                                                        onChange={(val) => updateRango(idx, 'max', val)}
                                                                        placeholder={rango.operador === 'MENOR_IGUAL' ? 'Valor' : 'Max'}
                                                                        className="w-full p-1.5 border border-slate-200 rounded text-sm outline-none focus:border-blue-400"
                                                                    />
                                                                )}
                                                            </div>
                                                        </div>

                                                        {/* Meta Objetivo */}
                                                        <div className="col-span-3 relative">
                                                            <div className="absolute left-2 top-2 text-slate-400"><Target className="w-4 h-4" /></div>
                                                            <CurrencyInput
                                                                value={rango.meta}
                                                                onChange={(val) => updateRango(idx, 'meta', val)}
                                                                className="w-full pl-8 pr-2 py-2 border border-slate-200 rounded text-sm outline-none focus:border-blue-400 font-medium"
                                                                placeholder="Meta"
                                                            />
                                                        </div>

                                                        {/* Comisión % */}
                                                        <div className="col-span-2 relative">
                                                            <DecimalInput 
                                                                value={rango.porcentaje}
                                                                onChange={(val) => updateRango(idx, 'porcentaje', val)}
                                                                className="w-full pl-2 pr-6 py-2 bg-blue-50 border border-blue-100 rounded text-sm font-bold text-blue-700 outline-none focus:ring-1 focus:ring-blue-400"
                                                            />
                                                            <Percent className="w-3 h-3 absolute right-2 top-3 text-blue-400" />
                                                        </div>

                                                        {/* Valor Fijo */}
                                                        <div className="col-span-2 relative">
                                                             <div className="absolute left-2 top-2 text-slate-400"><DollarSign className="w-4 h-4" /></div>
                                                             <CurrencyInput 
                                                                value={rango.valor}
                                                                onChange={(val) => updateRango(idx, 'valor', val)}
                                                                className="w-full pl-6 pr-1 py-2 border border-slate-200 rounded text-sm outline-none focus:border-green-400 font-medium text-slate-700"
                                                                placeholder="0"
                                                            />
                                                        </div>

                                                        <div className="col-span-1 flex justify-end">
                                                            <button onClick={() => deleteRango(idx)} className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors">
                                                                <Trash2 className="w-4 h-4" />
                                                            </button>
                                                        </div>
                                                    </div>
                                                ))}
                                                
                                                <button 
                                                    onClick={addRango}
                                                    className="border-2 border-dashed border-slate-300 rounded-xl p-3 text-slate-400 hover:border-blue-400 hover:text-blue-500 hover:bg-white transition-all flex items-center justify-center gap-2 font-medium text-sm"
                                                >
                                                    <Plus className="w-4 h-4" /> Añadir Nueva Escala
                                                </button>
                                            </div>
                                        )}

                                        {currentDetails.modo === 'META_UNICA' && (
                                            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
                                                <div className="flex flex-col md:flex-row gap-4 items-start">
                                                    
                                                    {/* Meta Objetivo */}
                                                    <div className="flex-1 w-full">
                                                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Meta Objetivo</label>
                                                        <div className="relative">
                                                            <Target className="w-5 h-5 absolute left-3 top-3.5 text-slate-300" />
                                                            <CurrencyInput 
                                                                value={currentDetails.metaUnica.meta}
                                                                onChange={(val) => updateParamDetails({ metaUnica: { ...currentDetails.metaUnica, meta: val } })}
                                                                className="w-full border-2 border-slate-200 rounded-xl pl-10 p-3 text-lg font-bold text-slate-700 outline-none focus:border-blue-500 transition-colors"
                                                                placeholder="0"
                                                            />
                                                        </div>
                                                    </div>

                                                    {/* Porcentaje */}
                                                    <div className="flex-1 w-full">
                                                        <label className="block text-xs font-bold text-blue-500 uppercase tracking-wider mb-2">Porcentaje</label>
                                                        <div className="relative">
                                                            <DecimalInput 
                                                                value={currentDetails.metaUnica.porcentaje}
                                                                onChange={(val) => updateParamDetails({ metaUnica: { ...currentDetails.metaUnica, porcentaje: val } })}
                                                                className="w-full bg-blue-50 border-2 border-blue-100 rounded-xl p-3 pr-10 text-lg font-bold text-blue-600 outline-none focus:border-blue-400 transition-colors"
                                                                placeholder="0"
                                                                alignRight
                                                            />
                                                            <Percent className="absolute right-3 top-3.5 text-blue-300 w-5 h-5" />
                                                        </div>
                                                    </div>
                                                    
                                                    {/* Divider + Y/O */}
                                                    <div className="hidden md:flex flex-col items-center justify-center pt-8">
                                                        <span className="text-xs text-slate-400 font-bold uppercase whitespace-nowrap">+ Y/O</span>
                                                    </div>

                                                    {/* Valor Fijo */}
                                                    <div className="flex-1 w-full">
                                                        <label className="block text-xs font-bold text-green-600 uppercase tracking-wider mb-2">Valor Fijo</label>
                                                        <div className="relative">
                                                            <CurrencyInput 
                                                                value={currentDetails.metaUnica.valor}
                                                                onChange={(val) => updateParamDetails({ metaUnica: { ...currentDetails.metaUnica, valor: val } })}
                                                                className="w-full bg-green-50 border-2 border-green-100 rounded-xl p-3 pl-10 text-lg font-bold text-green-700 outline-none focus:border-green-400 transition-colors"
                                                                placeholder="0"
                                                            />
                                                            <DollarSign className="absolute left-3 top-3.5 text-green-400 w-5 h-5" />
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        )}
                                    </div>

                                </div>
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center text-slate-400">
                                    <List className="w-12 h-12 mb-3 opacity-20" />
                                    <p className="text-sm font-medium">No hay reglas configuradas.</p>
                                    <p className="text-xs mt-1">Usa el botón "Agregar" para comenzar.</p>
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 bg-slate-50/50 rounded-xl border-2 border-dashed border-slate-200">
                    <User className="w-12 h-12 mb-2 opacity-50" />
                    <p>Selecciona un líder o crea uno nuevo</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
}