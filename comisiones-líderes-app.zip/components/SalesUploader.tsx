import React, { useState } from 'react';
import { AppStorageService } from '../services/storageService';
import { parseExcelVentas } from '../services/excelService';
import { Upload, FileType, CheckCircle, AlertCircle, Database, Info, RefreshCw } from 'lucide-react';
import { Venta } from '../types';

export default function SalesUploader({ storage }: { storage: AppStorageService }) {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<Venta[]>([]);
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [msg, setMsg] = useState('');
  const [detectedPeriods, setDetectedPeriods] = useState<string[]>([]);
  const [detectedDays, setDetectedDays] = useState<number[]>([]);
  const [lastUpload, setLastUpload] = useState<{count: number, name: string} | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setUploading(true);
      setStatus('idle');
      setLastUpload(null);
      try {
        const data = await parseExcelVentas(selectedFile);
        
        if (data.length === 0) {
            throw new Error("El archivo no contiene registros de venta válidos.");
        }

        // Identify periods in the file
        const periods = Array.from(new Set(data.map(v => `${new Date(0, v.mes-1).toLocaleString('es', {month: 'long'})} ${v.anio}`)));
        setDetectedPeriods(periods);

        // Identify unique days
        const days = Array.from(new Set(data.map(v => v.dia))).sort((a,b) => a-b);
        setDetectedDays(days);
        
        setPreview(data.slice(0, 5));
        setMsg(`Archivo analizado: ${data.length} registros.`);
      } catch (err: any) {
        setStatus('error');
        setMsg(err.message || "Error al leer el archivo Excel");
        setFile(null);
      } finally {
        setUploading(false);
      }
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    setUploading(true);
    try {
        const allData = await parseExcelVentas(file);
        
        if (allData.length === 0) {
            throw new Error("No se encontraron datos válidos.");
        }

        await storage.saveVentasBatch(allData, file.name);
        
        setStatus('success');
        setLastUpload({ count: allData.length, name: file.name });
        setPreview([]);
        setFile(null);
        setDetectedPeriods([]);
        setDetectedDays([]);
    } catch (err: any) {
        setStatus('error');
        setMsg(err.message || "Error al subir a Azure");
    } finally {
        setUploading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold text-slate-800">Carga de Ventas</h2>

      {status === 'success' && lastUpload && (
          <div className="bg-green-50 border border-green-200 rounded-xl p-6 flex flex-col items-center justify-center text-center animate-in fade-in slide-in-from-top-4">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-3">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-lg font-bold text-green-800">¡Carga Exitosa!</h3>
              <p className="text-green-700 mt-1">
                  Se han actualizado <span className="font-bold">{lastUpload.count}</span> registros. Los datos han sido fusionados con el histórico mensual.
              </p>
          </div>
      )}

      <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200 text-center">
        <div className={`border-2 border-dashed rounded-lg p-10 transition-colors relative ${file ? 'border-blue-300 bg-blue-50/30' : 'border-slate-300 hover:bg-slate-50'}`}>
            <input 
                type="file" 
                accept=".xlsx, .xls"
                onChange={handleFileChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                disabled={uploading}
            />
            <div className="flex flex-col items-center pointer-events-none">
                <Upload className={`w-12 h-12 mb-4 ${file ? 'text-blue-600' : 'text-slate-400'}`} />
                {file ? (
                     <div>
                        <p className="text-lg font-bold text-slate-800">{file.name}</p>
                        <p className="text-sm text-blue-600 font-medium mt-1">Click para cambiar archivo</p>
                     </div>
                ) : (
                    <div>
                        <p className="text-lg font-medium text-slate-700">Arrastra tu archivo Excel aquí</p>
                        <p className="text-sm text-slate-400 mt-2">bodega, año, mes, día, tipo_venta, valor</p>
                    </div>
                )}
            </div>
        </div>

        {file && status !== 'error' && (
            <div className="mt-6 text-left animate-in fade-in">
                
                {/* Warning about Overwriting */}
                <div className="mb-6 bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3 items-start">
                    <RefreshCw className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                        <p className="text-sm font-bold text-blue-800">Modo de Actualización: Fusión por Días</p>
                        <p className="text-xs text-blue-700 mt-1">
                            Periodos detectados: <span className="font-bold">{detectedPeriods.join(', ')}</span>.
                        </p>
                        <p className="text-xs text-blue-700 mt-1">
                            Se reemplazarán únicamente los datos de los días: <span className="font-bold bg-white px-1 rounded">{detectedDays.join(', ')}</span>.
                            Los datos de otros días del mes se mantendrán intactos.
                        </p>
                    </div>
                </div>

                <div className="flex justify-between items-center mb-4">
                    <h4 className="font-bold text-slate-700 flex items-center gap-2">
                        <Database className="w-4 h-4 text-slate-500" /> Vista Previa
                    </h4>
                    <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">{msg}</span>
                </div>
                
                {preview.length > 0 && (
                    <div className="overflow-x-auto border border-slate-200 rounded-lg">
                        <table className="w-full text-sm text-left">
                            <thead className="bg-slate-100 text-slate-600">
                                <tr>
                                    <th className="p-2 border-b">Bodega</th>
                                    <th className="p-2 border-b">Fecha</th>
                                    <th className="p-2 border-b">Concepto</th>
                                    <th className="p-2 border-b text-right">Valor</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 bg-white">
                                {preview.map((v, i) => (
                                    <tr key={i}>
                                        <td className="p-2">{v.bodega}</td>
                                        <td className="p-2">{v.anio}-{v.mes}-{v.dia}</td>
                                        <td className="p-2 text-xs truncate max-w-[150px]">{v.tipo_venta}</td>
                                        <td className="p-2 text-right font-mono">${v.valor.toLocaleString()}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
                
                <div className="mt-6 flex justify-end gap-3">
                     <button 
                        onClick={() => { setFile(null); setPreview([]); setStatus('idle'); }}
                        className="px-4 py-2 text-slate-500 hover:text-slate-700 text-sm font-medium"
                        disabled={uploading}
                    >
                        Cancelar
                    </button>
                    <button 
                        onClick={handleUpload}
                        disabled={uploading}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-bold disabled:opacity-50 flex items-center gap-2 shadow-lg shadow-blue-200"
                    >
                        {uploading ? (
                            <>
                                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                                Guardando...
                            </>
                        ) : (
                            <>
                                <Upload className="w-4 h-4" />
                                Subir y Actualizar
                            </>
                        )}
                    </button>
                </div>
            </div>
        )}

        {status === 'error' && (
            <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-lg flex items-center justify-center gap-2 border border-red-100 animate-in shake">
                <AlertCircle className="w-5 h-5" /> 
                <span className="whitespace-pre-line text-left">{msg}</span>
            </div>
        )}

      </div>
    </div>
  );
}
