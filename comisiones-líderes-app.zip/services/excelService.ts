import { read, utils } from 'xlsx';
import { Venta } from '../types';

export const parseExcelVentas = async (file: File): Promise<Venta[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        
        // Convert to JSON
        const jsonData = utils.sheet_to_json(sheet, { header: 1 });
        
        if (jsonData.length === 0) {
            reject(new Error("El archivo está vacío"));
            return;
        }

        // Normalize headers to handle variations
        const rawHeaders = (jsonData[0] as string[]).map(h => (h || '').toString().toLowerCase().trim());
        
        // Enhanced Header Mapping Logic with Exclusion
        // This prevents columns like "tipo venta" from being detected as "venta" (value) column
        const findIndex = (includes: string[], excludes: string[] = []) => {
            return rawHeaders.findIndex(h => {
                const matches = includes.some(term => h.includes(term));
                const excluded = excludes.some(term => h.includes(term));
                return matches && !excluded;
            });
        };

        const idxBodega = findIndex(['bodega', 'almacen', 'centro', 'agencia', 'sede']);
        const idxAnio = findIndex(['año', 'anio', 'year', 'vigencia']);
        const idxMes = findIndex(['mes', 'month', 'periodo']);
        const idxDia = findIndex(['día', 'dia', 'day', 'fecha']);
        
        // Specific logic: Look for 'tipo' but accept it.
        const idxTipo = findIndex(['tipo', 'concepto', 'familia', 'rubro', 'linea', 'producto']);
        
        // CRITICAL FIX: Look for 'valor'/'venta' but EXCLUDE 'tipo', 'concepto', 'familia' to avoid matching 'tipo venta' column
        const idxValor = findIndex(['valor', 'total', 'venta', 'monto', 'importe', 'facturado'], ['tipo', 'concepto', 'familia', 'fecha', 'dia', 'mes', 'año']);

        if (idxBodega === -1 || idxValor === -1) {
            // Detailed error to help user
            const missing = [];
            if(idxBodega === -1) missing.push("Bodega");
            if(idxValor === -1) missing.push("Valor");
            reject(new Error(`No se encontraron las columnas requeridas: ${missing.join(', ')}. \nColumnas detectadas: ${rawHeaders.join(', ')}`));
            return;
        }

        // Helper to parse months
        const parseMonth = (val: any): number => {
            if (typeof val === 'number') return val;
            if (!val) return new Date().getMonth() + 1;
            
            const str = String(val).toLowerCase().trim();
            if (!isNaN(Number(str))) return Number(str);
            
            const months = [
                ['ene', 'jan'], ['feb'], ['mar'], ['abr', 'apr'], ['may'], ['jun'], 
                ['jul'], ['ago', 'aug'], ['sep', 'set'], ['oct'], ['nov'], ['dic', 'dec']
            ];
            
            const idx = months.findIndex(m => m.some(x => str.includes(x)));
            return idx !== -1 ? idx + 1 : 1; 
        };

        const ventas: Venta[] = [];
        let skippedCount = 0;
        
        // Iterate starting from row 1 (index 1)
        for (let i = 1; i < jsonData.length; i++) {
          const row = jsonData[i] as any[];
          if (!row || row.length === 0) continue;

          // Safe get
          const getVal = (idx: number) => (idx > -1 && row[idx] !== undefined) ? row[idx] : null;

          // Bodega Parsing
          const rawBodega = getVal(idxBodega);
          const bodega = rawBodega !== null ? String(rawBodega).trim() : '';

          // Valor Parsing
          const rawValor = getVal(idxValor);
          let valorNum = 0;
          if (typeof rawValor === 'number') {
              valorNum = rawValor;
          } else if (typeof rawValor === 'string') {
              // Remove currency symbols, keep negative sign and decimals
              // Replace anything that is NOT a digit, dot, or minus
              const clean = rawValor.replace(/[^0-9.-]+/g,"");
              valorNum = parseFloat(clean);
          }

          // Date Parsing
          const anio = Number(getVal(idxAnio)) || new Date().getFullYear();
          const mes = parseMonth(getVal(idxMes));
          const dia = Number(getVal(idxDia)) || 1;

          // Tipo Venta Parsing
          const tipo = idxTipo > -1 ? String(getVal(idxTipo) || 'General').trim() : 'General';

          const v: Venta = {
            bodega,
            anio,
            mes,
            dia,
            tipo_venta: tipo,
            valor: valorNum
          };

          // Strict validation for valid row
          if (v.bodega && !isNaN(v.valor) && v.valor !== 0) {
            ventas.push(v);
          } else {
             skippedCount++;
          }
        }
        
        console.log(`Excel procesado: ${ventas.length} registros válidos, ${skippedCount} omitidos/vacíos`);
        resolve(ventas);

      } catch (err) {
        console.error(err);
        reject(new Error("Error procesando el archivo Excel. Verifique el formato."));
      }
    };
    reader.onerror = (err) => reject(err);
    reader.readAsBinaryString(file);
  });
};