import { PublicClientApplication, EventType, AccountInfo } from '@azure/msal-browser';

export const MSAL_CONFIG = {
  auth: {
    clientId: "ba5350b2-49e2-4a39-bff7-8b467147c695",
    authority: "https://login.microsoftonline.com/4dff4170-c25f-46b6-9c68-ab1e00975ef6",
    redirectUri: window.location.origin,
  },
  cache: {
    cacheLocation: "localStorage",
    storeAuthStateInCookie: false,
  },
};

// Scopes needed for basic profile. 
// Note: For Blob Storage, you usually need to assign RBAC roles to the user in Azure 
// or use a separate SAS token service. This config requests user impersonation if API permissions are set.
export const LOGIN_REQUEST = {
  scopes: ["User.Read", "openid", "profile"]
};

export const msalInstance = new PublicClientApplication(MSAL_CONFIG);

// Initialize MSAL
if (!msalInstance.getActiveAccount() && msalInstance.getAllAccounts().length > 0) {
  msalInstance.setActiveAccount(msalInstance.getAllAccounts()[0]);
}

msalInstance.addEventCallback((event) => {
  if (event.eventType === EventType.LOGIN_SUCCESS && event.payload) {
    const account = event.payload as AccountInfo;
    msalInstance.setActiveAccount(account);
  }
});

let isInitialized = false;

export const initializeMsal = async () => {
  if (isInitialized) return;
  try {
      await msalInstance.initialize();
      isInitialized = true;
  } catch (error) {
      console.log("MSAL Initialization skipped or failed (possibly already initialized)", error);
  }
};

export const getAccessToken = async (): Promise<string | null> => {
    const account = msalInstance.getActiveAccount();
    if(!account) return null;

    try {
        const response = await msalInstance.acquireTokenSilent({
            ...LOGIN_REQUEST,
            account: account
        });
        return response.accessToken;
    } catch (e) {
        // If silent fails, might need popup interaction, but usually handled by components
        console.error("Token silent acquisition failed", e);
        return null;
    }
}
