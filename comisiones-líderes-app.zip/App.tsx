import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { initializeMsal, msalInstance, getAccessToken } from './services/authService';
import { AppStorageService } from './services/storageService';
import { AuthState } from './types';
import { Package, Users, Calculator, FileSpreadsheet, LogOut, Menu, History, Wifi, WifiOff, Loader2 } from 'lucide-react';
import { BrowserAuthError } from '@azure/msal-browser';
import * as XLSX from 'xlsx';

import PeopleManager from './components/PeopleManager';
import SalesUploader from './components/SalesUploader';
import CommissionCalculator from './components/CommissionCalculator';
import LiquidationHistory from './components/LiquidationHistory';
import Login from './components/Login';

(window as any).XLSX = XLSX;

function Layout({ children, auth, onLogout, connectionStatus }: { children?: React.ReactNode, auth: AuthState, onLogout: () => void, connectionStatus: boolean }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { icon: Users, label: 'Líderes', path: '/personas' },
    { icon: FileSpreadsheet, label: 'Cargar Ventas', path: '/ventas' },
    { icon: Calculator, label: 'Liquidar', path: '/liquidar' },
    { icon: History, label: 'Historial', path: '/historial' },
  ];

  return (
    <div className="flex h-screen bg-slate-100">
      <aside className={`${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white transition-transform duration-300 md:relative md:translate-x-0`}>
        <div className="p-4 border-b border-slate-700 flex items-center gap-2">
          <Package className="w-8 h-8 text-blue-400" />
          <div>
            <h1 className="font-bold text-lg">Comisiones</h1>
            <p className="text-xs text-slate-400">Ver: 1.0.1 ({auth.mode})</p>
          </div>
        </div>
        
        <nav className="p-4 space-y-2">
          {navItems.map((item) => (
            <Link 
              key={item.path} 
              to={item.path}
              onClick={() => setSidebarOpen(false)}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${location.pathname === item.path ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>

        <div className="absolute bottom-0 w-full p-4 border-t border-slate-700">
            <div className="mb-2 flex items-center gap-2 text-xs">
                 {connectionStatus ? (
                     <span className="flex items-center gap-1 text-green-400"><Wifi className="w-3 h-3"/> Conectado</span>
                 ) : (
                     <span className="flex items-center gap-1 text-red-400"><WifiOff className="w-3 h-3"/> Sin Conexión</span>
                 )}
            </div>
            <div className="mb-4">
                <p className="text-sm font-medium">{auth.user?.name}</p>
                <p className="text-xs text-slate-400 truncate">{auth.user?.username}</p>
            </div>
            <button 
                onClick={onLogout}
                className="flex items-center gap-2 text-red-400 hover:text-red-300 text-sm w-full"
            >
                <LogOut className="w-4 h-4" /> Cerrar Sesión
            </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="bg-white border-b border-slate-200 p-4 flex items-center md:hidden">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-slate-600">
                <Menu className="w-6 h-6" />
            </button>
            <span className="ml-4 font-semibold text-slate-700">Menú</span>
        </header>
        <div className="flex-1 overflow-auto p-4 md:p-8">
            {children}
        </div>
      </main>

      {sidebarOpen && (
        <div 
            className="fixed inset-0 bg-black/50 z-40 md:hidden"
            onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}

export default function App() {
  const [isMsalReady, setIsMsalReady] = useState(false);
  const [auth, setAuth] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
    mode: 'local'
  });
  const [storageService, setStorageService] = useState<AppStorageService | null>(null);
  const [connectionValid, setConnectionValid] = useState(false);
  const [checkingConnection, setCheckingConnection] = useState(false);

  useEffect(() => {
    const init = async () => {
        try {
            await initializeMsal();
        } catch(e) {
            console.error("MSAL init error", e);
        } finally {
            setIsMsalReady(true);
        }
    };
    init();
  }, []);

  const handleLocalLogin = () => {
    setAuth({
      isAuthenticated: true,
      user: { name: 'Desarrollador Local', username: 'dev@localhost' },
      mode: 'local'
    });
    setStorageService(new AppStorageService('local'));
    setConnectionValid(true);
  };

  const setupAzureSession = async (account: any, token: string | undefined) => {
        // Initialize Service with Hardcoded Default Token from Service
        const service = new AppStorageService('azure'); 
        
        // Validate SAS Token connection
        const isValid = await service.validateConnection();
        
        if (!isValid) {
            alert("Autenticación correcta, pero no se pudo conectar al almacenamiento (Azure Blob). Verifica el Token SAS en el código.");
            setCheckingConnection(false);
            return;
        }

        setAuth({
            isAuthenticated: true,
            user: { 
                name: account?.name || 'Usuario', 
                username: account?.username || '' 
            },
            mode: 'azure',
            accessToken: token
        });
        
        setStorageService(service);
        setConnectionValid(true);
        setCheckingConnection(false);
  };

  const handleMicrosoftLogin = async () => {
    setCheckingConnection(true);
    try {
        // Check if there is already an active account to avoid duplicate popups
        const activeAccount = msalInstance.getActiveAccount();
        if (activeAccount) {
            console.log("Cuenta activa detectada, usando sesión existente.");
            await setupAzureSession(activeAccount, undefined); 
            return;
        }

        // Authenticate with MSAL
        const response = await msalInstance.loginPopup({
            scopes: ["User.Read"]
        });
        
        await setupAzureSession(response.account, response.accessToken);

    } catch (error: any) {
        console.error("Login failed", error);
        
        if (error instanceof BrowserAuthError && error.errorCode === "interaction_in_progress") {
             alert("Error de sesión: El navegador cree que ya hay un login en proceso. Por favor usa el botón 'Limpiar Caché' abajo para resetear.");
        } else {
             alert(`Error al iniciar sesión: ${error.message || 'Error desconocido'}`);
        }
        setCheckingConnection(false);
    }
  };

  const handleLogout = () => {
      if(auth.mode === 'azure') {
          msalInstance.logoutPopup().catch(e => console.error(e));
      }
      setAuth({ isAuthenticated: false, user: null, mode: 'local' });
      setStorageService(null);
      setConnectionValid(false);
  };

  const handleClearCache = () => {
      if(window.confirm("Esto borrará los datos temporales de sesión y recargará la página. ¿Continuar?")) {
          localStorage.clear();
          sessionStorage.clear();
          window.location.reload();
      }
  };

  if (!isMsalReady) {
      return (
          <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center text-white gap-4">
              <Loader2 className="w-10 h-10 animate-spin text-blue-500" />
              <p className="text-sm">Iniciando servicios de seguridad...</p>
          </div>
      );
  }

  if (!auth.isAuthenticated || !storageService) {
    return (
        <Login 
            onLocalLogin={handleLocalLogin} 
            onAzureLogin={handleMicrosoftLogin} 
            isLoading={checkingConnection}
            onClearCache={handleClearCache}
        />
    );
  }

  return (
    <HashRouter>
      <Layout auth={auth} onLogout={handleLogout} connectionStatus={connectionValid}>
        <Routes>
          <Route path="/" element={<Navigate to="/personas" replace />} />
          <Route path="/personas" element={<PeopleManager storage={storageService} />} />
          <Route path="/ventas" element={<SalesUploader storage={storageService} />} />
          <Route path="/liquidar" element={<CommissionCalculator storage={storageService} />} />
          <Route path="/historial" element={<LiquidationHistory storage={storageService} />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
}
