import React from 'react';
import { ShieldCheck, Database, Loader2, Cloud, RefreshCw } from 'lucide-react';

interface LoginProps {
  onLocalLogin: () => void;
  onAzureLogin: () => void;
  isLoading?: boolean;
  onClearCache?: () => void;
}

export default function Login({ onLocalLogin, onAzureLogin, isLoading = false, onClearCache }: LoginProps) {
  
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
        <div className="bg-blue-600 p-8 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-blue-500/20 backdrop-blur-sm z-0"></div>
          <div className="relative z-10">
              <ShieldCheck className="w-16 h-16 text-white mx-auto mb-4" />
              <h1 className="text-2xl font-bold text-white">Comisiones Líderes</h1>
              <p className="text-blue-100 mt-2">Sistema de Gestión y Liquidación</p>
          </div>
        </div>
        
        <div className="p-8 space-y-6">
          
          {/* Azure Login */}
          <div>
             <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                 <Cloud className="w-4 h-4"/> Entorno Producción (Azure)
             </h3>

             <button 
                onClick={onAzureLogin}
                disabled={isLoading}
                className="w-full bg-[#2F2F2F] hover:bg-[#1a1a1a] text-white font-semibold py-3 px-4 rounded-lg flex items-center justify-center gap-3 transition-all disabled:opacity-70 disabled:cursor-not-allowed"
             >
                {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                    <img src="https://learn.microsoft.com/en-us/azure/active-directory/develop/media/howto-add-branding-in-azure-ad-apps/ms-symbollockup_mssymbol_19.png" alt="MS" className="w-5 h-5" />
                )}
                {isLoading ? 'Conectando...' : 'Iniciar sesión con Microsoft'}
             </button>
             <p className="text-[10px] text-slate-400 mt-2 text-center">
                 Conecta al contenedor: <strong>comisiones-lideres</strong>
             </p>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-200"></div></div>
            <div className="relative flex justify-center text-sm"><span className="px-2 bg-white text-slate-500">O</span></div>
          </div>

          {/* Local Login */}
          <div>
            <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                <Database className="w-4 h-4"/> Entorno Pruebas
            </h3>
            <button 
                onClick={onLocalLogin}
                disabled={isLoading}
                className="w-full bg-white border-2 border-slate-200 hover:border-blue-400 text-slate-700 font-semibold py-3 px-4 rounded-lg flex items-center justify-center gap-3 transition-all"
            >
                <Database className="w-5 h-5 text-slate-500" />
                Modo Local (Offline)
            </button>
          </div>
          
          <div className="flex flex-col gap-2">
             <div className="bg-slate-50 p-3 rounded text-[10px] text-slate-400 break-all border border-slate-100 text-center">
                &copy; 2026 Sistema Interno
             </div>
             {onClearCache && (
                 <button 
                    onClick={onClearCache}
                    className="text-[10px] text-red-400 hover:text-red-500 hover:underline flex items-center justify-center gap-1"
                 >
                     <RefreshCw className="w-3 h-3" /> ¿Problemas de sesión? Limpiar Caché
                 </button>
             )}
          </div>

        </div>
      </div>
    </div>
  );
}
